-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2023 at 02:00 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `krit`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `fname` text NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `lname`, `email`, `mobile`, `username`, `pass`) VALUES
(2, 'manik', 'shaikh', 'shaikh@gmail.com', 9860448326, 'khan', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `aat_id` int(11) NOT NULL,
  `att_s_id` varchar(255) NOT NULL,
  `sname` text NOT NULL,
  `cname` text NOT NULL,
  `tcd` int(100) NOT NULL,
  `att_teacher` varchar(255) NOT NULL,
  `att_date` varchar(255) NOT NULL,
  `att_status` varchar(255) NOT NULL,
  `count` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`aat_id`, `att_s_id`, `sname`, `cname`, `tcd`, `att_teacher`, `att_date`, `att_status`, `count`) VALUES
(1, 'KRIT003', 'komal ram yadav', 'vba micros', 50, 'k', '2022-02-20', 'present', 5),
(2, 'KRIT004', 'komal lal singh', 'php', 90, 'k', '2022-02-20', 'present', 2),
(3, 'KRIT005', 'raj pal singh', 'mysql', 30, 'k', '2022-02-20', 'absent', 2),
(4, 'KRIT007', 'kajal lal sharma', 'microsoft 365', 90, 'k', '2022-02-20', 'present', 2),
(5, 'KRIT006', 'sanju vivek pandey', 'mysql', 120, 'k', '2022-02-20', 'absent', 1),
(6, 'KRIT009', 'abhi', 'advanced excel', 120, 'kriti', '2022-02-24', 'present', 1),
(7, 'KRIT005', 'raj pal singh', 'mysql', 30, 'k', '2022-02-24', 'present', 3),
(8, 'KRIT004', 'komal lal singh', 'php', 90, 'san', '2022-04-26', 'present', 3),
(9, 'KRIT010', 'sanchita', 'tally erp 9/prime', 60, 'KKK', '2022-05-26', 'present', 1);

-- --------------------------------------------------------

--
-- Table structure for table `demo`
--

CREATE TABLE `demo` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `sdate` date NOT NULL,
  `course` text NOT NULL,
  `query` varchar(100) NOT NULL,
  `date_time` datetime(5) NOT NULL DEFAULT current_timestamp(5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_data`
--

CREATE TABLE `enquiry_data` (
  `id` int(255) NOT NULL,
  `s_name` text NOT NULL,
  `s_mobile` bigint(255) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_addresh` varchar(255) NOT NULL,
  `s_course` text NOT NULL,
  `r_name` text NOT NULL,
  `r_mobile` bigint(255) NOT NULL,
  `staff_name` text NOT NULL,
  `s_feedback` varchar(255) NOT NULL,
  `enquiry_on` text NOT NULL,
  `type` text NOT NULL,
  `date_time` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `lfeedstaffname` text NOT NULL,
  `lupdate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiry_data`
--

INSERT INTO `enquiry_data` (`id`, `s_name`, `s_mobile`, `s_email`, `s_addresh`, `s_course`, `r_name`, `r_mobile`, `staff_name`, `s_feedback`, `enquiry_on`, `type`, `date_time`, `lfeedstaffname`, `lupdate`) VALUES
(1, 'manik', 1234567890, 'manik@gmail.com', 'xyz', 'java', 'manik1', 2147483647, 'krit', 'call 10/02/22', 'Cool', 'Cool', '2022-01-19 21:08:08.406591', 'rana singh', '2022-01-26'),
(3, 'test1', 1234567890, 'test@gmail.com', 'mumbai', 'java', 'ram ', 9876543210, 'diya', 'call karne ke liye bola hai 20/2/20', 'Tele calling', 'hot', '2022-01-19 21:18:09.173941', 'ram', '2022-01-26'),
(5, 'ram lal yadav', 2147483647, 'ram@gmail.com', 'mumbai', 'java', 'raju yadav', 2147483647, 'komal', 'call back 25/02/22', 'Website', 'Cool', '2022-01-21 19:55:19.101745', 'raj', '2022-01-26'),
(6, 'raj pal yadav', 9876543210, 'raj@gmail.com', 'mumbai', 'php', 'ram yadav', 7894561230, 'komal', 'tomorrow call 22/2/22', 'Tele Calling', 'Hot', '2022-01-21 19:58:56.951776', 'jarik', '2022-01-26'),
(7, 'sajid', 9860448326, 'saji@gmail.com', 'mumbai', 'java', 'tanvi', 9130523528, 'sachita', 'call back 20/2/22', 'Tele Calling', 'Cool', '2022-01-25 13:54:05.534130', '', ''),
(8, 'abhi', 8796080097, 'abhi@gmail.com', 'mumbai', 'Python Java php', 'website', 0, 'nikita rai', 'next months admission lene wala hai 25/2/20', 'Website', 'Hot', '2022-01-30 19:49:30.924641', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `otp` int(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `mobile`, `otp`, `date`) VALUES
(1, 'shaikh', 9860448326, 5454, '2022-02-20 21:08:53'),
(2, 'shaikh', 9860448326, 5454, '2022-02-20 21:08:53'),
(3, 'manik', 8796080097, 4545, '2022-02-20 21:12:23');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `p_id` int(11) NOT NULL,
  `p_s_id` varchar(100) NOT NULL,
  `p_sname` varchar(100) NOT NULL,
  `p_cname` varchar(100) NOT NULL,
  `p_total` varchar(100) NOT NULL,
  `p_paying` varchar(100) NOT NULL,
  `p_balance` varchar(100) NOT NULL,
  `paymod` text NOT NULL,
  `payrecname` varchar(100) NOT NULL,
  `p_teacher` varchar(100) NOT NULL,
  `p_date` varchar(100) NOT NULL,
  `count` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_id`, `p_s_id`, `p_sname`, `p_cname`, `p_total`, `p_paying`, `p_balance`, `paymod`, `payrecname`, `p_teacher`, `p_date`, `count`) VALUES
(1, 'KRIT003', 'komal ram yadav', 'vba micros', '20000', '1000', '8000', 'CASH', 'komal', 'k', '2022-02-20', 8),
(2, 'KRIT005', 'raj pal singh', 'mysql', '50000', '8000', '20000', 'ONLINE', 'raj', 'k', '2022-02-20', 7),
(3, 'KRIT006', 'sanju vivek pandey', 'mysql', '20000', '500', '7500', 'CHEQUE', 'sanju/85642356', 'k', '2022-02-20', 6),
(4, 'KRIT003', 'komal ram yadav', 'vba micros', '20000', '500', '7500', 'ONLINE', 'komal', 'k', '2022-02-20', 9),
(5, 'KRIT004', 'komal lal singh', 'php', '40000', '2000', '30000', 'ONLINE', 'komal singh', 'k', '2022-02-20', 5),
(6, 'KRIT007', 'kajal lal sharma', 'microsoft 365', '50000', '5000', '40000', 'ONLINE', 'kajal', 'k', '2022-02-20', 2),
(7, 'KRIT005', 'raj pal singh', 'mysql', '50000', '1000', '19000', 'ONLINE', 'raj', 'k', '2022-02-20', 8),
(8, 'KRIT007', 'kajal lal sharma', 'microsoft 365', '50000', '5000', '35000', 'CASH', 'kajal', 'k', '20-02-2022', 3),
(9, 'KRIT009', 'abhi', 'advanced excel', '40000', '20000', '20000', 'ONLINE', 'abhi', 'krit', '24-02-2022', 1),
(10, 'KRIT004', 'komal lal singh', 'php', '40000', '1000', '29000', 'CASH', 'komal', 'k', '10-03-2022', 6),
(11, 'KRIT010', 'sanchita', 'tally erp 9/prime', '6000', '6000', '0', 'CASH', '3000', 'KKK', '26-05-2022', 1);

-- --------------------------------------------------------

--
-- Table structure for table `request_connection`
--

CREATE TABLE `request_connection` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `course` text NOT NULL,
  `query` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request_connection`
--

INSERT INTO `request_connection` (`id`, `name`, `mobile`, `email`, `course`, `query`, `date`) VALUES
(1, 'shaikh', 9860448326, 'shaikh@gmail.com', 'Java', 'call me', '2022-02-21 01:59:01'),
(2, 'shaikh', 9860448326, 'abhi@gmail.com', 'C & C++', 'call me', '2022-02-24 13:52:58');

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `id` int(255) NOT NULL,
  `s_id` varchar(255) NOT NULL,
  `s_name` text NOT NULL,
  `s_mobile` bigint(255) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_dob` varchar(255) NOT NULL,
  `s_gender` text NOT NULL,
  `s_addresh` varchar(255) NOT NULL,
  `s_aadhar_no` varchar(255) NOT NULL,
  `s_qualification` varchar(255) NOT NULL,
  `course_type` text NOT NULL,
  `course_name` text NOT NULL,
  `course_day` int(255) NOT NULL,
  `att_status` text NOT NULL,
  `att_teacher` text NOT NULL,
  `last_att_date` varchar(100) NOT NULL,
  `last_att_count` int(100) NOT NULL,
  `course_time` varchar(255) NOT NULL,
  `course_amount` int(255) NOT NULL,
  `payamt` int(100) NOT NULL,
  `balamt` int(100) NOT NULL,
  `recamt` int(100) NOT NULL,
  `paystaffname` text NOT NULL,
  `paydate` varchar(10) NOT NULL,
  `payrecname` varchar(100) NOT NULL,
  `paymod` text NOT NULL,
  `s_rname` text NOT NULL,
  `s_rmobile` bigint(255) NOT NULL,
  `payment_mode` text NOT NULL,
  `count_of_amt` int(100) NOT NULL,
  `payment_date1` date NOT NULL,
  `payment_rs1` int(255) NOT NULL,
  `payment_date2` date NOT NULL,
  `payment_rs2` int(255) NOT NULL,
  `payment_date3` date NOT NULL,
  `payment_rs3` int(255) NOT NULL,
  `payment_date4` date NOT NULL,
  `payment_rs4` int(255) NOT NULL,
  `office_staff` varchar(255) NOT NULL,
  `up_staff_name` text NOT NULL,
  `date_time` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_registration`
--

INSERT INTO `student_registration` (`id`, `s_id`, `s_name`, `s_mobile`, `s_email`, `s_dob`, `s_gender`, `s_addresh`, `s_aadhar_no`, `s_qualification`, `course_type`, `course_name`, `course_day`, `att_status`, `att_teacher`, `last_att_date`, `last_att_count`, `course_time`, `course_amount`, `payamt`, `balamt`, `recamt`, `paystaffname`, `paydate`, `payrecname`, `paymod`, `s_rname`, `s_rmobile`, `payment_mode`, `count_of_amt`, `payment_date1`, `payment_rs1`, `payment_date2`, `payment_rs2`, `payment_date3`, `payment_rs3`, `payment_date4`, `payment_rs4`, `office_staff`, `up_staff_name`, `date_time`) VALUES
(10, 'KRIT003', 'komal ram yadav', 9876543210, 'komal@gmail.com', '1996-01-21', 'Female', 'mumbai,maharashtra', '123456789012', 'bcs it', 'non-it', 'vba micros', 50, 'present', 'k', '2022-02-20', 5, '01:00', 20000, 12500, 7500, 500, 'k', '2022-02-20', 'komal', 'ONLINE', 'rani sharma', 9876543120, 'osp', 9, '0000-00-00', 0, '0000-00-00', 0, '0000-00-00', 0, '0000-00-00', 0, 'kanchan', 'ankita', '2022-01-21 16:52:55.619248'),
(12, 'KRIT004', 'komal lal singh', 9876542580, 'komla@gmail.com', '1996-05-21', 'Female', 'mumbai', '985632564012', 'b.com', 'it', 'php', 90, 'present', 'san', '2022-04-26', 3, '02:30', 40000, 11000, 29000, 1000, 'k', '10-03-2022', 'komal', 'CASH', 'anita sharma', 7894562530, 'emi-four', 6, '2022-01-21', 10000, '2022-02-21', 10000, '2022-03-21', 10000, '2022-04-21', 10000, 'rani sharma', '', '2022-01-21 17:09:49.405563'),
(13, 'KRIT005', 'raj pal singh', 8654789250, 'raj@gmail.com', '1995-05-20', 'male', 'mumbai', '856423578561', 'hsc pass', 'it', 'mysql', 30, 'present', 'k', '2022-02-24', 3, '02:30', 50000, 31000, 19000, 1000, 'k', '2022-02-20', 'raj', 'ONLINE', 'ram', 8795345620, 'osp', 8, '0000-00-00', 0, '0000-00-00', 0, '0000-00-00', 0, '0000-00-00', 0, 'pooja', '', '2022-01-22 17:12:51.763115'),
(14, 'KRIT006', 'sanju vivek pandey', 9874561230, 'sanju@gmail.com', '1999-03-05', 'male', 'mumbai,maharashtra', '5647892460123', 'ssc', 'it', 'mysql', 120, 'absent', 'k', '2022-02-20', 1, '03:30', 20000, 12500, 7500, 500, 'k', '2022-02-20', 'sanju/85642356', 'CHEQUE', 'sanjay pandey', 7894561520, 'emi-four', 6, '2022-01-23', 5000, '2022-02-24', 5000, '2022-03-25', 5000, '2022-04-29', 5000, 'namrata gupta', '', '2022-01-23 00:13:32.518056'),
(15, 'KRIT007', 'kajal lal sharma', 9876543210, 'kajal@gmail.com', '1996-01-27', 'Female', 'mumbai', '456789123456', 'hsc', 'non-it', 'microsoft 365', 90, 'present', 'k', '2022-02-20', 2, '04:00', 50000, 15000, 35000, 5000, 'k', '20-02-2022', 'kajal', 'CASH', 'nikita singh', 8796542315, 'emi-three', 3, '2022-01-27', 20000, '2022-02-27', 15000, '2022-03-27', 15000, '0000-00-00', 0, 'krit singh', '', '2022-01-27 17:56:36.519544'),
(20, 'KRIT008', 'abhi ram kumar', 9876543310, 'abhi@gmail.com', '1995-05-25', 'male', 'mumbai', '654789256445', 'bsc it', 'it', 'java', 45, '', '', '', 0, '03:00', 45000, 0, 45000, 0, '', '', '', '', 'tanvi', 7894562586, 'emi-four', 0, '2022-02-20', 15000, '2022-03-20', 15000, '2022-04-20', 10000, '2022-05-20', 5000, 'kriti', '', '2022-02-20 20:20:21.859805'),
(21, 'KRIT009', 'abhi', 7894561230, 'abhi@gmail.com', '2022-02-24', 'male', 'mumbai', '4561231225865', 'bsc', 'non-it', 'advanced excel', 120, 'present', 'kriti', '2022-02-24', 1, '03:00', 40000, 20000, 20000, 20000, 'krit', '24-02-2022', 'abhi', 'ONLINE', 'tanvi', 7894561230, 'emi-three', 1, '2022-02-24', 20000, '2022-03-24', 10000, '2022-04-24', 10000, '0000-00-00', 0, 'kriti', '', '2022-02-24 13:55:57.988257'),
(22, 'KRIT010', 'sanchita', 9970695204, 'sanchita@gmail.com', '2003-03-03', 'Female', 'nalasopara', '984579723457', 'ba', 'non-it', 'tally erp 9/prime', 60, 'present', 'KKK', '2022-05-26', 1, '02:00', 6000, 6000, 0, 6000, 'KKK', '26-05-2022', '3000', 'CASH', '', 0, 'osp', 1, '0000-00-00', 0, '0000-00-00', 0, '0000-00-00', 0, '0000-00-00', 0, 'sanchita', '', '2022-05-26 16:42:14.883361');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`aat_id`);

--
-- Indexes for table `demo`
--
ALTER TABLE `demo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_data`
--
ALTER TABLE `enquiry_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `request_connection`
--
ALTER TABLE `request_connection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `aat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `demo`
--
ALTER TABLE `demo`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiry_data`
--
ALTER TABLE `enquiry_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `request_connection`
--
ALTER TABLE `request_connection`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student_registration`
--
ALTER TABLE `student_registration`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
