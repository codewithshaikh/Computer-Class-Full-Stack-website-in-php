 <?php 

session_start();
  ?>

  <!---------------------------------------------------- login --------------------------------------->

<?php 
include 'admin/dbcon.php';

// if ($con==TRUE) {

// 	echo "Connetion Successfully";
	
// }else{
// 	echo "Not Conneted to database";
// }


if (isset($_POST['submit'])) {
		$name=$_POST['name'];
		$mobile=$_POST['mobile'];
		
		$qry="SELECT * FROM `login` WHERE `name`='$name' AND `mobile`='$mobile'";

		$run= mysqli_query($con,$qry);

		$data=mysqli_fetch_assoc($run);
		

		if ($data<1) {
		?>	
		<script type="text/javascript">
			alert("Your name or mobile no. is wrong");
			 window.location.href='index.php';
		</script>
		<?php
		} else{
				header("location:home.php");
                $_SESSION['name'] = $name;
                $_SESSION['mobile'] = $mobile;
		}
}


 ?>

  <!-------------------------------- registion ---------------------------------------------------->


<?php

include 'admin/dbcon.php';
            
   if (isset($_POST['rsubmit'])) {
        $rname=$_POST['rname'];
        $rmobile=$_POST['rmobile'];
        $otp=$_POST['otp'];

        $insert_qry ="INSERT INTO `login` (`name`, `mobile`, `otp`) VALUES ('$rname' , '$rmobile' , '$otp')";


      $result = mysqli_query($con, $insert_qry);

      if($result)
      {
         echo "<script>
                       alert('Registration Successfully');
                        window.location.href='login.php';
                     </script>";
      }
      else{
        // echo "error";

        echo "<script>
                       alert('Some Data is not Correct');
                        window.location.href='login.php';
                     </script>";
      }
    }

?>