<?php

	include 'dbcon.php';

	 $id=$_GET['dsid'];
	 $query = "DELETE FROM student_registration WHERE s_id = '$id' ";

	 $data=mysqli_query($con, $query);

	 if($data)
	 {
	 	echo "<script>
                alert(' Delete Successfully');
                window.location.href='student_profile_update_delete.php';
              </script>";
	 }else{
	 	echo "<script>
                alert('Failed to Delete');
                window.location.href='student_profile_update_delete.php';
              </script>";
	 }
?>


