<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Update - (profile)</title>
        <link href="css/styles.css" rel="stylesheet" />

        <style>
            label {
                padding-left: 10px;
                font-weight: bold;
            }

            input[type=number]::-webkit-inner-spin-button,
            input[type=number]::-webkit-outer-spin-button{
              -webkit-appearance: none;
              margin: 0;
            }

        .card-header{
            background-color: #85C1E9;
            }
        .card-body{
            background-color: #D5D8DC;
        }

         body{
            background-image: url(img/Up-Date_Profile.jpg);
            width: 100%;
            height: 100vh;
        }

        </style>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header">
                                        <h3 class="text-center font-weight-light my-2">Up-Date Profile</h3>
                                       <a href="home.php" style="color:white; text-decoration: none; font-weight: bold;">Dashboard</a>
                                         <div class="mt-2 mb-0"></div>
                                        </div>
<div class="card-body">

 <form method="POST">
<?php

 include 'dbcon.php';

 $showqy = "select * from admin";

 $showdata = mysqli_query($con,$showqy);

 $res = mysqli_fetch_array($showdata);

 if(isset($_POST['submit'])){

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile  = $_POST['mobile'];
    $uname =$_POST['uname'];

    $qey =  "UPDATE admin SET `fname` ='$fname', `lname` ='$lname',`username`='$uname',`mobile` ='$mobile'";

    $row = mysqli_query($con,$qey);

    if ($con -> query($qey) == TRUE) {

                 echo  "<script>
                       alert('Profile Update Successfully');
                        window.location.href='home.php';
                     </script>";
                     $_SESSION['fname'] = $fname;



            }else{
                    // echo " Error ".$con->error;

                     echo "<script>
                       alert('Something are not correct');
                        window.location.href='profile.php';
                     </script>";
                 }
 }

?>
<div class="row mb-3">
 <div class="col-md-6">
    <label>First Name</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control" name="fname" id="inputFirstName" type="text" value="<?php echo $res['fname']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Last Name</label>
<div class="form-floating">
    <input class="form-control" name="lname" id="inputLastName" type="text" value="<?php echo $res['lname']; ?>" />
</div>
</div>
</div>

<label>Email I'D</label>
<div class="form-floating mb-3">
    <input class="form-control" name="email" id="inputEmail" type="password" value="<?php echo $res['email']; ?>" disabled/>
 </div>

 <label>Username</label>
<div class="form-floating mb-3">
    <input class="form-control" name="uname" id="inputEmail" type="text" value="<?php echo $res['username']; ?>"/>
 </div>

 <label>Mobile Number</label>
<div class="form-floating mb-3">
<input class="form-control" name="mobile" id="inputNumber" type="number" value="<?php echo $res['mobile']; ?>" />
</div>
<div class="mt-4 mb-0">
<div class="d-grid"><button class="btn btn-info btn-block" name="submit">Up-Date Profile</button></div>
     
</form>
        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
            </div>
            </div>
    </body>
</html>

