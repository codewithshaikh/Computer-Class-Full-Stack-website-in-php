<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Payment Details View</title>
        <link href="css/styles.css" rel="stylesheet" />
         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            label {
                padding-left: 10px;
                font-weight: bold;
            }

            input[type=number]::-webkit-inner-spin-button,
            input[type=number]::-webkit-outer-spin-button{
              -webkit-appearance: none;
              margin: 0;
            }

        .card-header{
            background-color: #85C1E9;
            }
        .card-body{
            background-color: #D5D8DC;
        }

        body{
            background-image: url(img/Payment_Details.jpg);
            width: 100%;
            height: 100vh;
        }

        </style>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-14">
                                <div class="card shadow-lg border-0 rounded-lg mt-3">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-0">Payment Details View</h3>
                                        <a href="home.php" style="color:white; text-decoration: none; font-weight: bold;">Dashboard</a>
                                         <div class="mt-1 mb-0"></div>
                                        </div>
<div class="card-body">
     <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0" method="POST">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for Student i'd" name="search_id" />

                    <button class="btn btn-primary" type="submit" name="search_btn"><i class="fas fa-search"></i>
                    </button>
                </div>
            </form><br><br>

<form method="POST">
        
             <table class="table table-dark table-striped">
              <thead>
                <tr>
                <th>Student's ID.</th>
                  <th>Student's Name</th>
                  <th>Student's Course</th>
                  <th>Total Amt.</th>
                  <th>Received Amt.</th>
                  <th>Balance Amt.</th>
                  <th>Payment MODE</th>
                  <th>Received From</th>
                  <th>Teacher</th>
                  <th>Date</th>
                  <th>Count</th>
                  <th>Download Latest Receipt</th>
                  <th ></th>
                </tr>
              </thead>
              <tbody  class="table table-Success">

                <?php

                 include 'dbcon.php';

                 if(isset($_POST['search_btn']))
                 {
                    $id = $_POST['search_id'];

                    $query = "SELECT * FROM payment WHERE p_s_id='$id'";

                    $query_run = mysqli_query($con, $query);

                        while($res = mysqli_fetch_array($query_run))
                        {
                 
                    ?>

                    <tr style= "text-align: center;">
                        <td><?php echo $res['p_s_id']; ?></td>
                        <td><?php echo $res['p_sname']; ?></td>
                        <td><?php echo $res['p_cname']; ?></td>
                        <td><?php echo $res['p_total']; ?></td>
                        <td><?php echo $res['p_paying']; ?></td>
                        <td><?php echo $res['p_balance']; ?></td>
                         <td><?php echo $res['paymod']; ?></td>
                        <td><?php echo $res['payrecname']; ?></td>
                        <td><?php echo $res['p_teacher']; ?></td>
                        <td><?php echo $res['p_date']; ?></td>
                        <td><?php echo $res['count']; ?></td>
                        <td ><a name="#" href="downloadrec.php?pdfid=<?php echo $res['p_id']; ?>"><i class="fas fa-download" style="color:#239B56; "></i></a></td>
                       </tr>

          <?php
                }
            }

            ?>
            </tbody>
        </table>
     
</form>


        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
            </div>
            </div>
    </body>
</html>

         
