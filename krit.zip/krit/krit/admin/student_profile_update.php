
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Student Profile Update</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <style>
                input[type=number]::-webkit-inner-spin-button,
                input[type=number]::-webkit-outer-spin-button{
                  -webkit-appearance: none;
                  margin: 0;
                }

            .form-group{
                padding: 10px;
            }

            .label{
                padding-left: 10px;
            }

            .label1{
                padding-left: 25px;
            }


            .select{
                padding: 5px;
                width: 150px;
            }
            label{
                padding-bottom: 5px;
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="home.php">Krit-Solution</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0" method="POST">
                <!-- <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for Student i'd"aria-describedby="btnNavbarSearch" name="search_id" >
                    <button class="btn btn-primary" type="submit" name="btnid"><i class="fas fa-search" ></i></button>
                </div> -->
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <!-- <li><a class="dropdown-item" href="#!">Profile</a></li> -->
                        <!-- <li><a class="dropdown-item" href="#!">Activity Log</a></li> -->
                        <!-- <li><hr class="dropdown-divider" /></li> -->
                        <li><a class="dropdown-item" href="index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="home.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                              <?php
                                   date_default_timezone_set('Asia/Kolkata');
                                    echo  date('h:i:s A');
                                ?>

                            </a>
                            <div class="sb-sidenav-menu-heading">Addons</div>
                            </a>
                            <a class="nav-link" href="student_profile_update.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Student Profile Update
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        KRIT-Dashboard 
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Student Profile Update</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="home.php">Dashboard</a></li>
                        </ol>
                     <div class="card mb-4">
                        <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                    Profile Update
            </div>
       <br>

    <?php 

     include 'dbcon.php';

     $ids = $_GET['usid'];

      $query = "SELECT * FROM student_registration WHERE s_id='$ids'";

      $query_run = mysqli_query($con, $query);

      $result = mysqli_fetch_array($query_run);


      if(isset($_POST['update_btn']))
      {
            $idss = $_GET['usid'];

            $sn = $_POST['s_name'];
            $sm = $_POST['s_mobile'];
            $se = $_POST['s_email'];
            $sdob = $_POST['s_dob'];
            $sg = $_POST['s_gender'];
            $sad = $_POST['s_add'];
            $sadh = $_POST['s_aadhar'];
            $sqly = $_POST['s_qly'];
            $sct = $_POST['s_course_time'];
            $osn = $_POST['ofice_s_name'];

             $update_qry =" UPDATE `student_registration` set `s_id`='$ids', `s_name`='$sn', `s_mobile`='$sm', `s_email`='$se', `s_dob`='$sdob', `s_gender`='$sg', `s_addresh`='$sad', `s_aadhar_no`='$sadh', `s_qualification`='$sqly', `course_time`='$sct', `up_staff_name`='$osn' where `s_id`='$idss' ";

            $result = mysqli_query($con, $update_qry);
            if($result)
            {
                ?>
                <script>
                   alert('Student Profile Update Successfully');
                    window.location.href='student_profile_update.php?usid=<?php echo $idss; ?>';
                </script>
                <?php
            }
            else{

                // echo " Error ".$con->error;

                echo "<script>
                       alert('Something is Wrong');
                        window.location.href='student_profile_update.php';
                     </script>";
            }

      }

 ?>

   <form method="POST"> 
    <h5> Student Details</h5>
    <div class="form-group">
      <label>Student ID :</label>
      <input type="text" class="form-control" name="" value="<?php echo $result['s_id']; ?>" disabled>
    </div>
     <div class="form-group">
      <label>Student Full Name :</label>
      <input type="text" class="form-control" name="s_name" value="<?php echo $result['s_name']; ?>">
    </div>
     <div class="form-group">
      <label>Student Mobile No. :</label>
      <input type="text" class="form-control" name="s_mobile" value="<?php echo $result['s_mobile']; ?>">
    </div>
    <div class="form-group">
      <label>Student E-mail I'd:</label>
       <input type="email" class="form-control" name="s_email" value="<?php echo $result['s_email']; ?>">
    </div>
    <div class="form-group">
      <label>Student Date Of Birth</label>
       <input type="text" class="form-control" name="s_dob" value="<?php echo $result['s_dob']; ?>">
    </div>
    <div class="form-group">
      <label class="label">Gender:</label>
   		<input type="text" class="form-control" name="s_gender" value="<?php echo $result['s_gender']; ?>">
    </div>
    <div class="form-group">
      <label>Student Full Address:</label>
       <input type="text" class="form-control" name="s_add" value="<?php echo $result['s_addresh']; ?>">
    </div>
    <div class="form-group">
      <label>Student Aadhar No. :</label>
       <input type="text" class="form-control" name="s_aadhar" value="<?php echo $result['s_aadhar_no']; ?>">
    </div>
     <div class="form-group">
      <label>Student Qualification</label>
      <input type="text" class="form-control" name="s_qly" value="<?php echo $result['s_qualification']; ?>">
    </div>
    <div class="form-group">
      <label>Student Lecture Time</label>
       <input type="text" class="form-control" name="s_course_time" value="<?php echo $result['course_time']; ?>">
    </div>
     <h5> Office Staff</h5>
      <div class="form-group">
      <label>Staff Name:</label>
        <input type="text" class="form-control" name="ofice_s_name" placeholder="Enter Staff Name *" required>
    </div>
     <br>
    <button type="submit" class="btn btn-info" name="update_btn" style="margin-left: 20%; padding-left: 35px; padding-right: 35px;">Update</button>
    <br><br>
</form>
        </div>
            </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; 2021. All rights reserved with krit solution</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>


             
    </body>
</html>






		 	