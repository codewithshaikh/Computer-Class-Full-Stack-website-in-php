<?php

include 'dbcon.php';

if (!$con) {
          die('Connection Error'.mysqli_error($con));       
      }
      else{        

		if(isset($_POST['submit'])){
			$sn = $_POST['s_name'];
			$sm = $_POST['s_mobile'];
			$se = $_POST['s_email'];
			$sdob = $_POST['s_dob'];
			$sg = $_POST['s_gender'];
			$sad = $_POST['s_add'];
			$sadh = $_POST['s_aadhar'];
			$sqly = $_POST['s_qly'];
			$sc = $_POST['s_course'];
			$scn = $_POST['s_course_name'];
			$scp = $_POST['s_course_price'];
			$scd = $_POST['s_course_day'];
			$sct = $_POST['s_course_time'];
			$srn = $_POST['s_rname'];
			$srm = $_POST['s_rmobile'];
			$sp = $_POST['s_payment_mode'];
			$sd1 = $_POST['epay1_date'];
			$sa1 = $_POST['epay1_rs'];
			$sd2 = $_POST['epay2_date'];
			$sa2 = $_POST['epay2_rs'];
			$sd3 = $_POST['epay3_date'];
			$sa3 = $_POST['epay3_rs'];
			$sd4 = $_POST['epay4_date'];
			$sa4 = $_POST['epay4_rs'];
			$osn = $_POST['ofice_s_name'];


			$checkuid = "SELECT * FROM `student_registration` ORDER BY id DESC LIMIT 1";
			$checkresult =mysqli_query($con, $checkuid);

			if(mysqli_num_rows($checkresult)>0)
			{

			if($row =mysqli_fetch_assoc($checkresult)){

				$student_registration = $row['s_id'];
				$get_number = str_replace("KRIT","", $student_registration);
				$id_increase = $get_number+1;
				$get_string = str_pad($id_increase, 3,0, STR_PAD_LEFT);
				$id = "KRIT".$get_string;


				$insert_qry ="INSERT INTO `student_registration`(`s_id`, `s_name`, `s_mobile`, `s_email`, `s_dob`, `s_gender`, `s_addresh`, `s_aadhar_no`, `s_qualification`, `course_type`, `course_name`, `course_day`, `course_time`, `course_amount`, `balamt`, `s_rname`, `s_rmobile`, `payment_mode`, `payment_date1`, `payment_rs1`, `payment_date2`, `payment_rs2`, `payment_date3`, `payment_rs3`, `payment_date4`, `payment_rs4`, `office_staff`) VALUES ('$id', '$sn', '$sm', '$se', '$sdob', '$sg', '$sad', '$sadh', '$sqly', '$sc', '$scn', '$scd', '$sct', '$scp', '$scp', '$srn', '$srm', '$sp', '$sd1', '$sa1', '$sd2', '$sa2', '$sd3', '$sa3', '$sd4', '$sa4', '$osn')";


			$result = mysqli_query($con, $insert_qry);
			if($result)
			{
				 echo "<script>
                       alert('Student Registration Successfully');
                        window.location.href='student_registion.php';
                     </script>";
			}
			else{
				// echo "error";

				echo "<script>
                       alert('Some Data is not Correct');
                        window.location.href='student_registion.php';
                     </script>";
			}


		}


	}

		else{

			$id = "KRIT001";

			$insert_qry ="INSERT INTO `student_registration`(`s_id`, `s_name`, `s_mobile`, `s_email`, `s_dob`, `s_gender`, `s_addresh`, `s_aadhar_no`, `s_qualification`, `course_type`, `course_name`, `course_day`, `course_time`, `course_amount`, `balamt`, `s_rname`, `s_rmobile`, `payment_mode`, `payment_date1`, `payment_rs1`, `payment_date2`, `payment_rs2`, `payment_date3`, `payment_rs3`, `payment_date4`, `payment_rs4`, `office_staff`) VALUES ('$id', '$sn', '$sm', '$se', '$sdob', '$sg', '$sad', '$sadh', '$sqly', '$sc', '$scn', '$scd', '$sct', '$scp', '$scp', '$srn', '$srm', '$sp', '$sd1', '$sa1', '$sd2', '$sa2', '$sd3', '$sa3', '$sd4', '$sa4', '$osn')";

			
			$result = mysqli_query($con, $insert_qry);
			if($result)
			{
				echo "<script>
                       alert('Student Registration Successfully');
                        window.location.href='student_registion.php';
                     </script>";
			}
			else{
				// echo "error";

				echo "<script>
                       alert('Something is Wrong');
                        window.location.href='student_registion.php';
                     </script>";
			}

			}


	}
}



?>