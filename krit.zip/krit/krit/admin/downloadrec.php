<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Payment</title>
        <link href="css/styles.css" rel="stylesheet" />
         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            label {
                padding-left: 10px;
                font-weight: bold;
            }

            input[type=number]::-webkit-inner-spin-button,
            input[type=number]::-webkit-outer-spin-button{
              -webkit-appearance: none;
              margin: 0;
            }

        .card-header{
            background-color: #85C1E9;
            }
        .card-body{
            background-color: #D5D8DC;
        }

         body{
            background-image: url(img/Download_Payment.jpg);
            width: 100%;
            height: 100vh;
        }

        </style>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="card shadow-lg border-0 rounded-lg mt-2">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-0">Download Payment Recepit </h3>
                                        <a href="home.php" style="color:white; text-decoration: none; font-weight: bold;">Dashboard</a>
                                         <div class="mt-1 mb-0"></div>
                                        </div>
<div class="card-body">
    <?php
     
     include 'dbcon.php';

     $ids = $_GET['pdfid'];

      $query = "SELECT * FROM payment WHERE p_id='$ids'";

      $query_run = mysqli_query($con, $query);

      $result = mysqli_fetch_array($query_run);


      ?>

<form action="indexpdf.php" method="POST">
<div class="row mb-3">
 <div class="col-md-6">
    <label>Student I'D</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control" id="inputFirstName" type="text" name="search_id_hidden"  readonly value="<?php echo $result['p_s_id']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Student Name</label>
<div class="form-floating">
    <input class="form-control" id="inputLastName" name="sname" type="text" readonly value="<?php echo $result['p_sname']; ?>" />
</div>
</div>
</div>

<div class="row mb-3">
 <div class="col-md-6">
    <label>Course Name</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control" id="inputFirstName" name="p_cname" type="text"  readonly value="<?php echo $result['p_cname']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Total Course Amount</label>
<div class="form-floating">
    <input class="form-control" name="totalcouamt" id="inputLastName" type="text" readonly value="<?php echo $result['p_total']; ?>" />
</div>
</div>
</div>

<div class="row mb-3">
    <div class="col-md-6">
    <label>Paying Amount</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="payamt" id="inputPassword" type="number" readonly value="<?php echo $result['p_paying']; ?>">
    </div>
    </div>
                                    
    <div class="col-md-6">
    <label>Balance Amount</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="balamt" id="inputPassword" type="number" readonly value="<?php echo $result['p_balance']; ?>">
    </div>
    </div>
</div>

<div class="row mb-3">
    <div class="col-md-6">
    <label>Received From</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="payrecname" id="inputPassword" type="text" readonly value="<?php echo $result['payrecname']; ?>">
    </div>
    </div>
                                    
    <div class="col-md-6">
    <label>Accept Payment Staff Name</label>
    <div class="form-floating mb-3 mb-md-0">
        <input class="form-control" name="paystaffname" id="inputPassword" type="text" readonly value="<?php echo $result['p_teacher']; ?>">
    </div>
    </div>
</div>

<div class="row mb-3">
    <div class="col-md-6">
    <label>Last Payment Date</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="paydate" id="inputPassword" readonly value="<?php echo $result['p_date']; ?>" readonly>
    </div>
    </div>
                                    
    <div class="col-md-6">
    <label>MODE of Payment</label>
    <div class="form-floating mb-3 mb-md-0">
        <input class="form-control" name="paymod" id="inputPassword" readonly type="text" value="<?php echo $result['paymod']; ?>">
    </div>
    </div>
</div>

<div class="mt-1 mb-1">

    <label>Payment Count</label>
    <input type="number" name="" style="padding: 2px; margin-right: 2px; font-weight: bold;" readonly value="<?php echo $result['count']; ?>" >
    
<button class="btn btn-info btn-block" type="submit" name="pdfsubmit" style="margin-left:120px; font-weight: bold;"><i class="fas fa-download" style="color:#239B56; "></i> Download Recepit</button>
</div>
     
</form>

        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
            </div>
            </div>
    </body>
</html>
