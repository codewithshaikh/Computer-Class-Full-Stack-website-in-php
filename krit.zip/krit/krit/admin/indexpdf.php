<?php 

require("pdf/fpdf.php");

$pdf = new FPDF('P','mm','A4');

$pdf->AddPage();

 include 'dbcon.php';

if(isset($_POST['pdfsubmit']))
 {

   $id = $_POST['search_id_hidden'];
   $sname = $_POST['sname'];
   $cname = $_POST['p_cname'];
   $bamt = $_POST['balamt'];
   $pamt =$_POST['payamt'];
   $totalcouamt =$_POST['totalcouamt'];
   $psn = $_POST['paystaffname'];
   $prn = $_POST['payrecname'];
   $mod = $_POST['paymod'];
   $payd = $_POST['paydate'];


                        
                 

//set font to arial, bold, 16pt
$pdf->SetFont('Arial','B',30);

//Cell(width , height , text , border , end line , [align] )

$pdf->Cell(189  ,5,'KR IT EDUCATION',0,1,'C');

$pdf->SetFont('Arial','',14);

$pdf->Cell(189  ,9,'Borivali Centre of Kr it Education Institue of Skill Training ',0,1,'C');

$pdf->Line(10, 23, 200, 23);

// $pdf->Cell(189  ,8,'',0,1);

$pdf->SetFont('Arial','',11);

$pdf->Cell(189  ,5,'Room No.101/1st Floor,ABCD Building,Mumbai, Maharashtra, 123456.  Phone +91 9876543210',0,1,'C');

$pdf->Line(10, 30, 200, 30);

$pdf->Cell(189  ,8,'',0,1);

$pdf->SetFont('Arial','B',20);
$pdf->Cell(186   ,5,'RECEIPT',0,1,'C');


$pdf->SetFont('Arial','',12);


// $pdf->Cell(189  ,5,'',0,0);
$pdf->Cell(28  ,5,'Student Name',0,0);
$pdf->SetFont('','B',12);
$pdf->Cell(4 ,5,':',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(98  ,5,$sname,0,0);

$pdf->Cell(22   ,5,'Date',0,0);
$pdf->SetFont('','B',12);
$pdf->Cell(3 ,5,':',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(34   ,5,$payd,0,1);

// $pdf->Cell(189  ,5,'',0,0);
$pdf->Cell(28  ,5,'Course Name',0,0);
$pdf->SetFont('','B',12);
$pdf->Cell(4 ,5,':',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(98  ,5,$cname,0,0);

$pdf->Cell(22   ,5,'Student ID',0,0);
$pdf->SetFont('','B',12);
$pdf->Cell(3 ,5,':',0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(34   ,5,$id,0,1);


$pdf->Cell(189  ,8,'',0,1);


$pdf->SetFont('Arial','B',12);

$pdf->Cell(63  ,10,'Payment Receiver',1,0);
$pdf->Cell(63   ,10,'Payment MODE',1,0);
$pdf->Cell(63   ,10,'Total Amount',1,1);

$pdf->SetFont('Arial','',12);

$pdf->Cell(63  ,8,$psn,1,0);
$pdf->Cell(63   ,8,$mod,1,0);
$pdf->Cell(63   ,8,$totalcouamt,1,1,'R');


//summary
$pdf->Cell(130  ,5,'',0,0);
$pdf->Cell(25   ,5,'Balance',0,0);
$pdf->Cell(10    ,5,'Amt.',1,0);
$pdf->Cell(24   ,5,$bamt,1,1,'R');

$pdf->Cell(130  ,5,'',0,0);
$pdf->Cell(25   ,5,'Received',0,0);
$pdf->Cell(10    ,5,'Amt.',1,0);
$pdf->Cell(24   ,5,$pamt,1,1,'R');

$pdf->Line(10, 92, 200, 92);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(189  ,15,'This Is System Generated Receipt No Signature Required.',0,1,'C');

$file = $id.'.pdf';

$pdf->Output($file,'D');

 }

 ?>

 