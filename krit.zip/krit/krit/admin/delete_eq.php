<?php

	 include 'dbcon.php';

	 $ideq=$_GET['deqd'];
	 $query = "DELETE FROM enquiry_data WHERE s_name = '$ideq' ";

	 $data=mysqli_query($con, $query);

	 if($data)
	 {
	 	echo "<script>
                alert(' Delete Successfully');
                window.location.href='vieweqform.php';
              </script>";
	 }else{
	 	echo "<script>
                alert('Failed to Delete');
                window.location.href='vieweqform.php';
              </script>";
	 }
?>