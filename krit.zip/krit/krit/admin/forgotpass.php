<?php
session_start();

?>
<!DOCTYPE html>
<php lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Forgot - Admin</title>
        <link href="css/login_style.css" rel="stylesheet" />
      <!--  <script language="javascript" type="text/javascript">
         window.history.forward();
       </script> -->
    </head>
    <body>
            <div class="login-box">
              <h2>Forgot Password</h2>
              <form action="#"  method="POST">
                <div class="user-box">
                  <input type="text" name="idp" required="">
                  <label>Enter ID No.</label>
                </div>
                <div class="user-box">
                  <input type="password" name="pass" required="">
                  <label>Enter New Password</label>
                </div>
                <button type="submit" name="submit" value="login">
                  Submit
                </button> 
                <a style="color:white; margin-left: 180px;" href="forgotuser.php">Forgot Username?</a>
              </form>
            </div>
    </body>
</html>


<?php

    $con= mysqli_connect('localhost','root','','krit');

     if(isset($_POST['submit'])){

         $idpf = $_POST['idp'];

         $fpass = $_POST['pass'];

         $qey =  "UPDATE admin SET `pass` ='$fpass' where `email`='$idpf'";

         $row = mysqli_query($con,$qey);

         if($row == TRUE)
         {
           
            ?>
                  <script>
                        alert('Password Change Successfully')
                         window.location.href='index.php';
                      </script>

                      <?php

                  
         }else{ 
          ?>
                     <script>
                        alert('Your ID Is Not Correct')
                        window.location.href='index.php';
                      </script>
          <?php        
         }


     }

?>
