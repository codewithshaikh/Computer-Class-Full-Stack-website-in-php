<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Student Admission</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <style>
                input[type=number]::-webkit-inner-spin-button,
                input[type=number]::-webkit-outer-spin-button{
                  -webkit-appearance: none;
                  margin: 0;
                }

            .form-group{
                padding: 10px;
            }

            .label{
                padding-left: 10px;
            }

            .label1{
                padding-left: 25px;
            }


            .select{
                padding: 5px;
                width: 150px;
            }
            label{
                padding-bottom: 5px;
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="home.php">Krit-Solution</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
               <!--  <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div> -->
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <!-- <li><a class="dropdown-item" href="#!">Profile</a></li> -->
                        <!-- <li><a class="dropdown-item" href="#!">Activity Log</a></li> -->
                        <!-- <li><hr class="dropdown-divider" /></li> -->
                        <li><a class="dropdown-item" href="index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="home.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                              <?php
                                   date_default_timezone_set('Asia/Kolkata');
                                    echo  date('h:i:s A');
                                ?>

                            </a>
                            <div class="sb-sidenav-menu-heading">Addons</div>
                            </a>
                            <a class="nav-link" href="student_registion.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Student Registration
                            </a>
                           <!--  <a class="nav-link" href="enquireform.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Enquiry Form
                            </a>
                            <a class="nav-link" href="vieweqform.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                View Enquiry Form
                            </a> -->
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        KRIT-Dashboard 
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Student Admission</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="home.php">Dashboard</a></li>
                        </ol>
                     <div class="card mb-4">
                        <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                    Student Admission Form 
            </div>
       <br>        
  <form action="stu_reg_connection.php" method="POST">
    
    <h5> Student Personal Information Details</h5>
     <div class="form-group">
      <label>Student Full Name :</label>
      <input type="text" class="form-control" placeholder="Enter Student Name as on aadhar*" name="s_name" autocomplete="off" required>
    </div>
     <div class="form-group">
      <label>Student Mobile No. :</label>
      <input type="number" class="form-control" placeholder="Enter Student Mobile*" name="s_mobile" autocomplete="off" required>
    </div>
    <div class="form-group">
      <label>Student E-mail I'd:</label>
      <input type="email" class="form-control" placeholder="Enter Student Email*" name="s_email" autocomplete="off"required>
    </div>
    <div class="form-group">
      <label>Student Date Of Birth.:</label>
      <input type="date" class="form-control" placeholder="Enter Student Email*" name="s_dob" autocomplete="off"required>
    </div>
    <div class="form-group">
      <label class="label">Select Gender.:</label>
      <select class="select" required  name="s_gender">
       <option>-- Select Here --</option>
      <option value="male">Male</option>
      <option value="Female">Female</option>
      <option value="Other">Other</option>
      </select>
    </div>
    <div class="form-group">
      <label>Student Full Address:</label>
      <input type="text" class="form-control" placeholder="Enter Student Full Address as on aadhar*" name="s_add" autocomplete="off" required>
    </div>
    <div class="form-group">
      <label>Student Aadhar No. :</label>
      <input type="number" class="form-control" placeholder="Enter Aadhar Number*" name="s_aadhar" autocomplete="off" required>
    </div>
     <div class="form-group">
      <label>Student Qualification.:</label>
      <input type="text" class="form-control" placeholder="Enter Student Qualification*" name="s_qly" autocomplete="off" required>
    </div>
    <br>
    <h5>Course</h5>
    <div class="form-group">
      <label class="label">Select Course Type.:</label>
      <select class="select" required  name="s_course" id="slc1" onchange="selectcourse(this.id,'slc2')">
      <option>-- Select Here --</option>
      <option value="non-it">Non-IT Course</option>
      <option value="it">IT Course</option>
      </select>
    <!-- </div>
    <div class="form-group"> -->
      <label class="label1" >Select Course Name:</label>
      <select class="select" required  name="s_course_name" id="slc2">
      <option>-- Select Here --</option>
      </select>

      <label class="label1" >Total Course Amount:</label>
      <input type="number" class="select" placeholder="Enter Amount" name="s_course_price">
      </select>
    </div>
    <div class="form-group">
      <label>How Many Day's Complete Course </label>
      <input type="number" class="form-control" placeholder="Enter Day's in Number*" name="s_course_day" autocomplete="off" required>
    </div>
    <div class="form-group">
      <label>Student Lecture Time</label>
      <input type="time" class="form-control" name="s_course_time" autocomplete="off" required>
    </div><br>
    <h5> Reference</h5>
    <div class="form-group">
      <label>Reference Name:</label>
      <input type="text" class="form-control" placeholder="Enter Student Reference Name (Optional)" name="s_rname" autocomplete="off">
    </div>
     <div class="form-group">
      <label>Reference Mobile:</label>
      <input type="number" class="form-control" placeholder="Enter Student Reference Mobile (Optional)" name="s_rmobile" autocomplete="off">
    </div><br>
    <h5>Payment Method</h5> 
      <div class="form-group">
      <select class="select" required  name="s_payment_mode" id="pmc1" onchange="pmc(this.id,'searchemi')">
      <option>-- Select Here --</option>
      <option value="osp">One Short Payment</option>               
      <option value="emi-two">Two Short Payment</option>
      <option value="emi-three">Three Short Payment</option>
      <option value="emi-four">Four Short Payment</option>
      </select>

      <label id="searchemi"></label>

        <div style="padding: 8px;" hidden id="epay1">
          <label>First Payment: </label>
          <input type="date" name="epay1_date">
          <input type="number" placeholder="Enter Amount" name="epay1_rs">
          </div>

          <div style="padding: 8px;" hidden id="epay2">
          <label>Next Payment: </label>
          <input type="date" name="epay2_date">
          <input type="number" placeholder="Enter Amount" name="epay2_rs">
          </div>

           <div style="padding: 8px;" hidden id="epay3">
          <label>Next Payment: </label>
          <input type="date" name="epay3_date">
          <input type="number" placeholder="Enter Amount" name="epay3_rs">
          </div>

          <div style="padding: 8px;" hidden id="epay4">
          <label>Next Payment: </label>
          <input type="date" name="epay4_date">
          <input type="number" placeholder="Enter Amount" name="epay4_rs">
          </div>
      </div>

         <br>
         <h5> Office Staff</h5>
          <div class="form-group">
          <label>Staff Name:</label>
      <input type="text" class="form-control" placeholder="Enter Name *" name="ofice_s_name" autocomplete="off" required>
    </div>
     <br>
    <button type="submit" class="btn btn-primary" name="submit" style="margin-left: 40%; padding-left: 35px; padding-right: 35px;">Submit</button>
    <br><br>
</form>
        </div>
            </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; 2021. All rights reserved with krit solution</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>

<!-- select course  java query-->
            <script>
            
                function selectcourse(slc1,slc2)
                {
                    var s1 =document.getElementById(slc1);
                    var s2 =document.getElementById(slc2);

                    s2.innerHTML = "";

                    if(s1.value == "non-it")
                    {
                        var optionArray = ['tally erp 9/prime|Tally ERP 9/Prime','microsoft 365|Microsoft 365','advanced excel|Advanced EXCEL','vba micros|VBA Micros'];
                    }
                    else if(s1.value == "it")
                    {
                        var optionArray = ['java|Java','php|Php','mysql|My-Sql','python|Python','c/c++|C & C++'];
                    }

                    for(var option in optionArray)
                    {
                        var pair = optionArray[option].split("|");
                        var newoption = document.createElement("option");

                        newoption.value = pair[0];
                        newoption.innerHTML=pair[1];
                        s2.options.add(newoption);

                    }

                     
                }

             </script>



<!-- select Payment Emi  java query-->

             <script>
                 
             function pmc(pmc1,searchemi)
                {
                    var p1 =document.getElementById(pmc1);
                    var se =document.getElementById(searchemi);

                     se.innerHTML = "";

                // if(p1.value == "osp")
                // {
                //     document.getElementById("epay1").hidden = false;
                // }

                if(p1.value == "emi-two")
                    {
                        document.getElementById("epay1").hidden = false;
                         document.getElementById("epay2").hidden = false;
                    }
                    else if(p1.value == "emi-three")
                    {
                        document.getElementById("epay1").hidden = false;
                         document.getElementById("epay2").hidden = false;
                         document.getElementById("epay3").hidden = false;
                    }
                    else if(p1.value == "emi-four")
                    {
                        document.getElementById("epay1").hidden = false;
                         document.getElementById("epay2").hidden = false;
                         document.getElementById("epay3").hidden = false;
                         document.getElementById("epay4").hidden = false;
                    }
                }

             </script>
    </body>
</html>
