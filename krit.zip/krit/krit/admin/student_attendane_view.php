<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Student Attendane View</title>
        <link href="css/styles.css" rel="stylesheet" />
         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            label {
                padding-left: 10px;
                font-weight: bold;
            }

            input[type=number]::-webkit-inner-spin-button,
            input[type=number]::-webkit-outer-spin-button{
              -webkit-appearance: none;
              margin: 0;
            }

        .card-header{
            background-color: #85C1E9;
            }
        .card-body{
            background-color: #D5D8DC;
        }

        body{
            background-image: url(img/Student_AttendanceV.jpg);
            width: 100%;
            height: 100%;
        }


        </style>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="card shadow-lg border-0 rounded-lg mt-3">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-0">Student Attendance View</h3>
                                        <a href="home.php" style="color:white; text-decoration: none; font-weight: bold;">Dashboard</a>
                                         <div class="mt-1 mb-0"></div>
                                        </div>
<div class="card-body">
     <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0" method="POST">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for Student i'd" name="search_id" />

                    <button class="btn btn-primary" type="submit" name="search_btn"><i class="fas fa-search"></i>
                    </button>
                </div>
            </form><br><br>
        
             <table class="table table-dark table-striped">
              <thead>
                <tr>
                <th>Student ID.</th>
                  <th>Student Name</th>
                  <th>Course</th>
                  <th>Status</th>
                  <th>Teacher</th>
                  <th>Date</th>
                  <th>Count</th>
                  <th ></th>
                </tr>
              </thead>
              <tbody  class="table table-secondary">

                <?php

                 include 'dbcon.php';

                 if(isset($_POST['search_btn']))
                 {
                    $id = $_POST['search_id'];

                    $query = "SELECT * FROM attendence WHERE att_s_id='$id'";

                    $query_run = mysqli_query($con, $query);

                        while($res = mysqli_fetch_array($query_run))
                        {
                 
                    ?>

                    <tr>

                        <td><?php echo $res['att_s_id']; ?></td>
                        <td><?php echo $res['sname']; ?></td>
                        <td><?php echo $res['cname']; ?></td>
                        <td><?php echo $res['att_status']; ?></td>
                        <td><?php echo $res['att_teacher']; ?></td>
                        <td><?php echo $res['att_date']; ?></td>
                        <td><?php echo $res['count']; ?></td>
                       </tr>

          <?php
                }
            }

            ?>
            </tbody>
        </table>
 
        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
            </div>
            </div>
    </body>
</html>

         
