<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Update Enquiry Form</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <style>
                input[type=number]::-webkit-inner-spin-button,
                input[type=number]::-webkit-outer-spin-button{
                  -webkit-appearance: none;
                  margin: 0;
                }

                .form-group{
                padding: 10px;
                }
        </style>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="home.php">Krit-Solution</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <!-- <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div> -->
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="home.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                              <?php
                                   date_default_timezone_set('Asia/Kolkata');
                                    echo  date('h:i:s A');
                                ?>

                            </a>
                            <div class="sb-sidenav-menu-heading">Addons</div>
                            </a>
                            <a class="nav-link" href="enquireform.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Enquiry Form
                            </a>
                            <a class="nav-link" href="updateeq.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Update Enquiry Form
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        KRIT-Dashboard
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Update Enquiry Form</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="home.php">Dashboard</a></li>
                        </ol>
                     <div class="card mb-4">
                        <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                   Update Enquiry Management
            </div>
       <br>        
  <form method="POST">

    <?php 

     include 'dbcon.php';

     $idup = $_GET['ueqid'];

      $query = "SELECT * FROM enquiry_data WHERE s_name='$idup'";

      $query_run = mysqli_query($con, $query);

      $result = mysqli_fetch_array($query_run);


      if(isset($_POST['ueq_btn']))
      {
            $idupeq = $_GET['ueqid'];

            $upn = $_POST['name'];
            $upm = $_POST['mobile'];
            $upe = $_POST['email'];
            $upadd = $_POST['add'];
            $upcou = $_POST['course'];
            $uprn = $_POST['r_name'];
            $uprm = $_POST['r_mobile'];
            $upsn = $_POST['ss_name'];
            $upfed = $_POST['s_feed'];     
            $upt = $_POST['s_type'];
            $update = $_POST['up_date'];

             $update_qry =" UPDATE `enquiry_data` set `s_name`='$upn', `s_mobile`=
             '$upm', `s_email`='$upe', `s_addresh`='$upadd', `s_course`='$upcou', `r_name`='$uprn', `r_mobile`='$uprm', `lfeedstaffname`='$upsn', `s_feedback`='$upfed', `type`='$upt', `lupdate`='$update' where `s_name`='$idupeq'";

            $result = mysqli_query($con, $update_qry);
            if($result)
            {
                ?>
                <script>
                   alert('Enquiry Update Successfully');
                    window.location.href='vieweqform.php';
                </script>
                <?php
            }
            else{

                // echo " Error ".$con->error;

                echo "<script>
                       alert('Something is Wrong');
                        window.location.href='student_profile_update.php';
                     </script>";
            }

      }

 ?>


    <h5> Student Details Update</h5>
    <div class="form-group">
      <label>Enquiry ON:</label>
      <input type="text" class="form-control" autocomplete="off" value="<?php echo $result['enquiry_on']; ?>" disabled>
    </div>
     <div class="form-group">
      <label>Student Full Name:</label>
      <input type="text" class="form-control"  name="name" autocomplete="off" value="<?php echo $result['s_name']; ?>" >
    </div>
     <div class="form-group">
      <label>Student Mobile no. :</label>
      <input type="number" class="form-control" name="mobile" autocomplete="off" value="<?php echo $result['s_mobile']; ?>" >
    </div>
    <div class="form-group">
      <label>E-mail I'd:</label>
      <input type="email" class="form-control"  name="email" autocomplete="off" value="<?php echo $result['s_email']; ?>">
    </div>
    <div class="form-group">
      <label>Addresh:</label>
      <input type="text" class="form-control"  name="add" autocomplete="off" value="<?php echo $result['s_addresh']; ?>" >
    </div>
    <div class="form-group">
      <label>Course:</label>
      <input type="text" class="form-control"  name="course" autocomplete="off" value="<?php echo $result['s_course']; ?>" >
    </div><br>

    <h5> Referencer</h5>
    <div class="form-group">
      <label>Referencer Name:</label>
      <input type="text" class="form-control"  name="r_name" autocomplete="off" value="<?php echo $result['r_name']; ?>">
    </div>
     <div class="form-group">
      <label>Referencer Mobile:</label>
      <input type="number" class="form-control" name="r_mobile" autocomplete="off" value="<?php echo $result['r_mobile']; ?>">
    </div><br>

     <h5> Office Staff</h5>
      <div class="form-group">
      <label>Staff Name:</label>
      <input type="text" class="form-control" name="ss_name" placeholder="Enter Feedback Update Staff Name*" autocomplete="off" required>
    </div>
     <div class="form-group">
      <label>Student Feedback:</label>
      <input type="text" class="form-control" name="s_feed" autocomplete="off" value="<?php echo $result['s_feedback']; ?>">
    </div>
     <div class="form-group">
      <label>Select Type:</label>
      <input type="text" class="form-control" name="s_type" autocomplete="off" value="<?php echo $result['type']; ?>">
    </div>
     <div class="form-group">
      <label>Feedback Date:</label>
      <input type="date" class="form-control" name="up_date" autocomplete="off" required>
    </div>
    <button type="submit" class="btn btn-info" name="ueq_btn" style="margin-left: 20%;">Update Student Enquiry</button>
    <br>
    <br>
  </form>
        </div>
            </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; 2021. All rights reserved with krit solution</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>

<?php

   include 'dbcon.php';

      // if ($con==TRUE) {
      //         echo "Conneted to database successfully";      // database name-: class
      // }else{                                             // table name -:  contact_form
      //   echo "Not Conneted to database";
      // }
          if (isset($_POST['submit'])) {
                $enquiry_on=$_POST['enquiry_on'];
                $name=$_POST['name'];
                $mobile=$_POST['mobile'];
                $email=$_POST['email'];
                $add=$_POST['add'];
                $course=$_POST['course'];
                $rname=$_POST['r_name'];
                $rmobile=$_POST['r_mobile'];
                $sname=$_POST['ss_name'];
                $sfeed=$_POST['s_feed'];
                $type=$_POST['type'];
                


              $qy = " INSERT INTO `enquiry_data`(`s_name`, `s_mobile`, `s_email`, `s_addresh`, `s_course`, `r_name`, `r_mobile`, `staff_name`, `s_feedback`, `enquiry_on`, `type`) value ('$name' , '$mobile' , '$email' ,'$add' , '$course' , '$rname' , '$rmobile' , '$sname' , '$sfeed' , '$enquiry_on' , '$type')";



              $run = mysqli_query($con,$qy);

               if($run==TRUE){

                // if ($con -> query($qy) == TRUE) {   //( check table connection error )

                echo "<script>
                       alert(' Feedback is Successfully Submited');
                        window.location.href='enquireform.php';
                     </script>";
            }else{

                // echo " Error ".$con->error;  // ( error findout)

                echo "<script>
                       alert(' Data is not submited');
                        window.location.href='enquireform.php';
                     </script>";
                }

          }
  ?>
