<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Student - Attendance</title>
        <link href="css/styles.css" rel="stylesheet" />
         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            label {
                padding-left: 10px;
                font-weight: bold;
            }

            input[type=number]::-webkit-inner-spin-button,
            input[type=number]::-webkit-outer-spin-button{
              -webkit-appearance: none;
              margin: 0;
            }

        .card-header{
            background-color: #85C1E9;
            }
        .card-body{
            background-color: #D5D8DC;
        }

         body{
            background-image: url(img/Student_Attendance.jpg);
            width: 100%;
            height: 100%;
        }

        </style>
    </head>
   <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-9">
                                <div class="card shadow-lg border-0 rounded-lg mt-4">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-0">Student Attendance</h3>
                                        <a href="home.php" style="color:white; text-decoration: none; font-weight: bold;">Dashboard</a>
                                         <div class="mt-1 mb-0"></div>
                                        </div>
<div class="card-body">
     <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0" method="POST">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for Student i'd" name="search_id" />

                    <button class="btn btn-primary" type="submit" name="search_btn"><i class="fas fa-search"></i>
                    </button>
                </div>
            </form><br><br>

        <?php

         include 'dbcon.php';

         if(isset($_POST['search_btn']))
         {
            $id = $_POST['search_id'];

            $query = "SELECT * FROM student_registration WHERE s_id='$id'";

            $query_run = mysqli_query($con, $query);

                while($res = mysqli_fetch_array($query_run))
                {
                 ?>

 <form method="POST">

<div class="row mb-3">
 <div class="col-md-6">
    <label>Student I'D</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control"  id="inputFirstName" type="text" name="search_id_hidden"  readonly value="<?php echo $res['s_id']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Student Name</label>
<div class="form-floating">
    <input class="form-control" name="sname" id="inputLastName" type="text" readonly value="<?php echo $res['s_name']; ?>" />
</div>
</div>
</div>

<div class="row mb-3">
 <div class="col-md-6">
    <label>Course Name</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control"  id="inputFirstName" name="cname" type="text"  readonly value="<?php echo $res['course_name']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Total Course Day's</label>
<div class="form-floating">
    <input class="form-control" name="tcd" id="inputLastName" type="text" readonly value="<?php echo $res['course_day']; ?>" />
</div>
</div>
</div>

<div class="row mb-3">
    <div class="col-md-6">
    <label>Teacher Name</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="teacher" id="inputPassword" type="text" required>
    </div>
    </div>
                                    
    <div class="col-md-6">
    <label>Date</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="date" type="date" value="<?php echo date('Y-m-d'); ?>" readonly>
    </div>
    </div>
    <input class="form-control" name="attcount"  type="hidden" value="<?php echo $res['last_att_count']; ?>">
</div>


<div class="mt-3 mb-0">
    <select style="width: 18%; padding:5px; font-weight: bold;" name="status">
    <option value="present" selected style="font-weight: bold; ">Present</option>
    <option value="absent" style="font-weight: bold;">Absent</option>
    </select>

<button class="btn btn-success btn-block" name="submit" style="width: 20%; margin-left:30px !important">Submit</button>
</div>
     
</form>

         <?php
                }
            }
         ?>


        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
            </div>
            </div>
    </body>
</html>



<?php

include 'dbcon.php';
  
     if(isset($_POST['submit']))
    {
         $id = $_POST['search_id_hidden'];
         $date = $_POST['date'];
         $status=$_POST['status'];

         $qy= "SELECT * FROM `attendence` WHERE att_date = '$date'And att_s_id='$id'";

         $qyf = mysqli_query($con,$qy);


        if(mysqli_num_rows($qyf)>0)
        {
                 ?>
                    <script>
                       alert('Attendance All Ready Taken Today !!!!');
                        window.location.href='student_attendance.php';
                    </script>
                    <?php

       
        }else{

        $id = $_POST['search_id_hidden'];
        $sname =$_POST['sname'];
        $cname =$_POST['cname'];
        $tcd =$_POST['tcd'];
        $status=$_POST['status'];
        $tea = $_POST['teacher'];
        $date = $_POST['date'];
        $attc = $_POST['attcount'];

        $attcs = $attc + 1;



      $insert_qry = "INSERT INTO `attendence`(`att_s_id`, `sname`, `cname`, `tcd`, `att_teacher`, `att_date`, `att_status`,`count`) VALUES  ('$id','$sname','$cname','$tcd','$tea','$date','$status','$attcs')";

       $update_qry = "UPDATE `student_registration` SET `att_status` = '$status', `att_teacher` = '$tea', `last_att_date` = '$date', `last_att_count` = '$attcs' WHERE `student_registration`.`s_id` = '$id';";

        $results = mysqli_query($con,$update_qry);

                  $result = mysqli_query($con,$insert_qry);
                if($result)
                {
                    ?>
                    <script>
                       alert('Attendance Successfully Mark');
                        window.location.href='student_attendance.php';
                    </script>
                    <?php
                }
                else{

                echo " Error ".$con->error;

            }
               
            
        }
      }


?>






















         