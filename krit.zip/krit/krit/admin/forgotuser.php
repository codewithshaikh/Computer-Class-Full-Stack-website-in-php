<?php
session_start();

?>
<!DOCTYPE html>
<php lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Forgot - Admin</title>
        <link href="css/login_style.css" rel="stylesheet" />
      <!--  <script language="javascript" type="text/javascript">
         window.history.forward();
       </script> -->
    </head>
    <body>
            <div class="login-box">
              <h2>Forgot UserName</h2>
              <form method="POST">
                <div class="user-box">
                  <input type="text" name="idu" required="">
                  <label>Enter ID No.</label>
                </div>
                <div class="user-box">
                  <input type="text" name="uname" required="">
                  <label>Enter New Username</label>
                </div>
                <button type="submit" name="submit" value="login">
                  Submit
                </button> 
              </form>
            </div>
    </body>
</html>
<?php

    $con= mysqli_connect('localhost','root','','krit');

     if(isset($_POST['submit'])){

         $iduf = $_POST['idu'];

         $funame = $_POST['uname'];

         $qey =  "UPDATE admin SET `username` ='$funame' where `email`='$iduf'";

         $row = mysqli_query($con,$qey);

         if($row)

         {
            ?>
                 <script>
                    alert('Username Change Successfully')
                     window.location.href='index.php';
                  </script>

                  <?php
         }else{

               ?>
                 <script>
                    alert('Your ID Is Not Correct ')
                    window.location.href='index.php';
                  </script>

                  <?php
         }


     }

?>