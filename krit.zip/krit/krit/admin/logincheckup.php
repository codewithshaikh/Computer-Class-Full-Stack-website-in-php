<?php 

session_start();
?>

<?php 
include 'dbcon.php';

// if ($con==TRUE) {
	
// }else{
// 	echo "Not Conneted to database";
// }


if (isset($_POST['submit'])) {
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		
		
		$qry="SELECT * FROM `admin` WHERE `username`='$user' AND `pass`='$pass'";

		$run= mysqli_query($con,$qry);

		$data=mysqli_fetch_assoc($run);
		

		if ($data<1) {
		?>	
			<script>
				alert("Your Username or password is Wrong");
				 window.location.href='index.php';
			</script>
		<?php
		} else{
			
				header("location:home.php");
						$_SESSION['user'] = $user;
		}
}


 ?>