<?php
session_start();

?>
<!DOCTYPE html>
<php lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Login - Admin</title>
        <link href="css/login_style.css" rel="stylesheet" />
       <script language="javascript" type="text/javascript">
         window.history.forward();
       </script>
    </head>
    <body>
            <div class="login-box">
              <h2>Login</h2>
              <form action="logincheckup.php" method="POST">
                <div class="user-box">
                  <input type="text" name="user" required="">
                  <label>Username</label>
                </div>
                <div class="user-box">
                  <input type="password" name="pass" required="">
                  <label>Password</label>
                </div>
                <button type="submit" name="submit" value="login">
                  Submit
                </button> 
                <a style="color:white; margin-left: 180px;" href="forgotpass.php">Forgot Password?</a>

              </form>
            </div>
    </body>
</html>
