<?php

	 include 'dbcon.php';
	 
	  $idb=$_GET['dbd'];

	 $query = "DELETE FROM demo where id = '$idb'";

	 $data=mysqli_query($con, $query);

	 if($data)
	 {
	 	?>	
			<script>
				alert(" Delete Successfully");
				 window.location.href='home.php';
			</script>
		<?php
	 }else{
	 	echo "<script>
                alert('Failed to Delete');
                window.location.href='b_delete.php';
              </script>";
	 }
?>