<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Payment</title>
        <link href="css/styles.css" rel="stylesheet" />
         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            label {
                padding-left: 10px;
                font-weight: bold;
            }

            input[type=number]::-webkit-inner-spin-button,
            input[type=number]::-webkit-outer-spin-button{
              -webkit-appearance: none;
              margin: 0;
            }

        .card-header{
            background-color: #85C1E9;
            }
        .card-body{
            background-color: #D5D8DC;
        }

         body{
            background-image: url(img/Payment_Accept.jpg);
            width: 100%;
            height: 100vh;
        }

        </style>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-3">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-0">Payment Accept</h3>
                                        <a href="home.php" style="color:white; text-decoration: none; font-weight: bold;">Dashboard</a>
                                         <div class="mt-1 mb-0"></div>
                                        </div>
<div class="card-body">
     <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0" method="POST">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for Student i'd" name="search_id" />

                    <button class="btn btn-primary" type="submit" name="search_btn"><i class="fas fa-search"></i>
                    </button>
                </div>
            </form><br><br>

<form method="POST">
        <?php

         include 'dbcon.php';

         if(isset($_POST['search_btn']))
         {
            $id = $_POST['search_id'];

            $query = "SELECT * FROM student_registration WHERE s_id='$id'";

            $query_run = mysqli_query($con, $query);

                while($res = mysqli_fetch_array($query_run))
                {
                 

                ?>

<div class="row mb-3">
 <div class="col-md-6">
    <label>Student I'D</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control" id="inputFirstName" type="text" name="search_id_hidden"  readonly value="<?php echo $res['s_id']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Student Name</label>
<div class="form-floating">
    <input class="form-control" id="inputLastName" name="p_sname" type="text" readonly value="<?php echo $res['s_name']; ?>" />
</div>
</div>
</div>

<div class="row mb-3">
 <div class="col-md-6">
    <label>Course Name</label>
 <div class="form-floating mb-3 mb-md-0">
<input class="form-control" id="inputFirstName" name="p_cname" type="text"  readonly value="<?php echo $res['course_name']; ?>" />
</div>
</div>

 <div class="col-md-6">
     <label>Total Course Amount</label>
<div class="form-floating">
    <input class="form-control" name="totalcouamt" id="inputLastName" type="text" readonly value="<?php echo $res['course_amount']; ?>" />
</div>
</div>
</div>

<div class="row mb-3">
    <div class="col-md-6">
    <label>Paying Amount</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="payamt" id="inputPassword" type="number" readonly value="<?php echo $res['payamt']; ?>">
    </div>
    </div>
                                    
    <div class="col-md-6">
    <label>Balance Amount</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="balamt" id="inputPassword" type="number" value="<?php echo $res['balamt']; ?>">
    </div>
    </div>
</div>

<div class="row mb-3">
    <div class="col-md-6">
    <label>Received From</label>
    <div class="form-floating mb-3 mb-md-0">
    <input class="form-control" name="payrecname" id="inputPassword" type="text" required>
    </div>
    </div>
                                    
    <div class="col-md-6">
    <label>Accept Payment Staff Name</label>
    <div class="form-floating mb-3 mb-md-0">
        <input class="form-control" name="paystaffname" id="inputPassword" type="text" value="" required>
    </div>
    </div>
</div>

<div class="col-md-4">
<!-- <label>Date/Count Of Payment (+1)</label> -->
 <div class=" mb-2">
 <input class="form-control" name="paydate" id="inputPassword" type="hidden" value="<?php echo date('d-m-Y'); ?>" readonly>

<input class="form-control" name="paycount"  type="hidden" value="<?php echo $res['count_of_amt']; ?>" >
</div>
</div>


<div class="mt-3 mb-2">

    <label>Payment MOD</label>
    <select style="padding: 5px; font-weight: bold;" name="pmod">
        <option value="CASH">CASH</option>
        <option value="CHEQUE">CHEQUE</option>
        <option value="ONLINE">ONLINE</option>
    </select>

<button class="btn btn-info btn-block" type="submit" name="submit" style="margin-left:30px; font-weight: bold;">Payment Accept</button>

<a type="submit" name="pdfsubmit" href="downloadrec.php?pdfid=<?php echo $res['s_id']; ?>" style="margin-left:20px; font-weight: bold; color: green; text-decoration:none;">Generate Receipt</a>

</div>
     
</form>

         <?php

                }
            }
         ?>


        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
            </div>
            </div>
    </body>
</html>

             <?php

              include 'dbcon.php';

                  if(isset($_POST['submit']))
               {

                    $id = $_POST['search_id_hidden'];

                    $sname = $_POST['p_sname'];
                    $cname = $_POST['p_cname'];
                    $bamt = $_POST['balamt'];
                    $pamt =$_POST['payamt'];
                    $totalcouamt =$_POST['totalcouamt'];

                    $payamt = $bamt + $pamt;

                    $blamts =  $totalcouamt - $payamt ;
                    
                    $psn = $_POST['paystaffname'];
                    $prn = $_POST['payrecname'];
                    $mod = $_POST['pmod'];
                    $payd = $_POST['paydate'];
                    $payc = $_POST['paycount'];

                    $paycs = $payc + 1;

                   

            $update_qry = "UPDATE `student_registration` SET `payamt` = '$payamt', `balamt` = '$blamts',`recamt` = '$bamt', `payrecname`='$prn', `paymod`='$mod', `paystaffname` = '$psn', `paydate` = '$payd', `count_of_amt` = '$paycs' WHERE `student_registration`.`s_id` = '$id';";

            $insert_qry ="INSERT INTO `payment`(`p_s_id`, `p_sname`, `p_cname`, `p_total`, `p_paying`, `p_balance`, `paymod`, `payrecname`, `p_teacher`, `p_date`,`count`) VALUES ('$id','$sname','$cname','$totalcouamt','$bamt','$blamts','$mod','$prn','$psn','$payd','$paycs')";

             $results = mysqli_query($con, $insert_qry);


                  $result = mysqli_query($con, $update_qry);
                if($result)
                {
                    ?>
                    <script>
                       alert('Payment Accept Successfully');
                        window.location.href='pay_slip.php';
                    </script>
                    <?php

                } else{

                echo " Error ".$con->error;

                // echo "<script>
                //        alert('Something is Wrong');
                //         window.location.href='payment_acc.php';
                //      </script>";
            }

      }

 ?>
         
