 <?php 

session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>KRIT EDUCATION</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

     <!------------------------header links Start--------------------------------------------------->

      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
       
   <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    
      <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.6.2/animate.min.css" rel="stylesheet">

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

       <!------------------------header links end--------------------------------------------------->
      
      <!-- title bar icon -->
      <link rel="shortcut icon" type="image/x-icon" href="imgs/logo.jpg">

      <!-- alert massage -->
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

      <!-- home icone -->
      <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <style>

      #popupeq_demo{
        background-image:linear-gradient(rgba(0, 0, 0,0.5),rgba(0, 0, 0,0.5)), url('imgs/eqbgimg.jpg');
      }
    </style>

</head>
<body>


       

<!--------------------Demo loder Start ----------------------------------------------------->

    <form action="request_connection.php" method="POST">
        <div id="popupmaineq_demo" style="display:none;">
            <div id="popupeq_demo">
            <h1 id="headindeq">Book Demo  <button class="closedeq">X</button> </h1>

            <input type="text" name="name_d" id="poptexteq1_demo" placeholder="Enter Your Name*" required> <br>

            <input type="number" name="" id="poptexteq1_demo" placeholder="<?php echo $_SESSION['mobile'] ?>" disabled><br>
            
             <input type="email" name="email_d" id="poptexteq1_demo" placeholder="Enter Your Email*" required><br>

            <input type="date" name="date_d" id="poptexteq1_demo" placeholder="Select Date*" required><br>

             <select id="poptexteq1_demo" name="selectop_d" required>
                <option>Select Course</option>
                 <option value="Java">Java</option>
                 <option value="Python">Python</option>
                 <option value="C & C++">C & C++</option>
                 <option value="php">Php</option>
                 <option value="Hadoop">Hadoop</option>
                 <option value="Node JS">Node js</option>
                 <option value="React js/Native">React JS/Native</option>
                 <option value="Data Science">Data Science</option>
                 <option value="Other">Other</option>
             </select><br>

            <input type="text" name="query_d" id="poptexteq2_demo" placeholder="Write Your query" required><br>

             <input type="hidden" id="poptexteqs" value="Select Your Option ">

            <input type="hidden" id="poptexteqq" value="Enter Your Query ">

            <button class="popsubmiteq_demo" name="submit_d">Send Request</button>
            
          </div>
        </div>
        </form>


<!-------------Demo loder end ----------------------------------------------------->

<!---------------------- header Start ----------------------------------------------------->

	<section id="home">

         

	   <header>
        <nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
            <div class="container">
               
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=" #bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Mobile menu bar</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#" style="font-size: 30px !important;"> KRIT EDUCATION</a>
                </div>

              
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#home"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#about"><i class="fas fa-coffee"></i> About</a></li>
                        <li><a href="#courses"><i class="fab fa-css3-alt"></i> Courses</a></li>
                        <li><a href="#gallery"><i class="fab fa-envira"></i> Gallery</a></li>
                        <li><a href="#OurTeachers"><i class="fas fa-chalkboard-teacher"></i> Our Teachers</a></li>
                        <li><a href="#footer"><i class="fas fa-phone"></i> Contact</a></li>
<li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Logout { <?php echo $_SESSION['name'] ?> }</a></li>
                    </ul>
                </div>
            </div>
        </nav>


        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <div class="banner" style="background-image:url('imgs/img1.jpg');"></div>
                    <div class="carousel-caption">
                        <h2 class="animated bounceInRight" style="animation-delay: 1s">Welcome to <span>KRIT EDUCATION</span></h2>
                        <h3 class="animated bounceInLeft" style="animation-delay: 2s"><?php echo $_SESSION['name'] ?></h3>
                        <p class="animated bounceInRight" style="animation-delay: 3s"><a href="#" onclick="popuph()"> Book Demo Know ?</a></p>
                    </div>
                </div>
                <div class="item">
                    <div class="banner" style="background-image: url(imgs/img2.jpg);"></div>
                    <div class="carousel-caption">
                        <h2 class="animated slideInDown" style="animation-delay: 1s">Learn With <span>KRIT EDUCATION</span></h2>
                        <h3 class="animated fadeInUp" style="animation-delay: 2s">IMPROVE WITH YOUR SELF</h3>
                        <p class="animated zoomIn" style="animation-delay: 3s"><a href="#" onclick="popuph()">Demo Book ?</a></p>
                    </div>
                </div>
                <div class="item">
                    <div class="banner" style="background-image: url(imgs/img3.jpg);"></div>
                    <div class="carousel-caption">
                        <h2 class="animated zoomIn" style="animation-delay: 1s">Learn With <span>KRIT EDUCATION</span></h2>
                        <h3 class="animated fadeInLeft" style="animation-delay: 2s">IMPROVE WITH YOUR SELF</h3>
                        <p class="animated zoomIn" style="animation-delay: 3s"><a href="#" onclick="popuph()">Demo Book ?</a></p>
                    </div>
                </div>

            </div>

            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

    </header>


</section>
<!--------------------------- header End --------------------------------------------------------->

<!--------------------------About Start--------------------------------------------------------->

    <section id="about">
        
            <div class="about-section">
              <h1 class="animated slideInDown" style="animation-delay: 1s">What We Offer</h1>
              <p class="animated zoomIn" style="animation-delay: 2s">We provide online/offline conceptual and practical group and individual</p>
              <p class="animated zoomIn" style="animation-delay: 2s">training with good knowledge and good cost and excellent study</p>
               <p class="animated zoomIn" style="animation-delay: 2s">materials We provide job placement in top best IT companies</p>
            </div>

            <div class="arow">
              <div class="acolumn">
                <div class="acard">
                  <img src="imgs/resion.png" alt="Jane" style="width:100%">
                  <div class="acontainer">
                    <h2 class="animated bounceInLeft" style="animation-delay: 1s">Reasons to join us</h2>
                    <p class="animated bounceInLeft" style="animation-delay: 2s"><i class="fa fa-check"></i> Well experienced and Professional Trainer</p>
                    <p class="animated bounceInLeft" style="animation-delay: 3s"><i class="fa fa-check"></i> Have a deeper knowledge of skillsets</p>
                    <p class="animated bounceInLeft" style="animation-delay: 4s"><i class="fa fa-check"></i> Flexibility in scheduling of lectures timing.</p>
                    <p class="animated bounceInLeft" style="animation-delay: 5s"><i class="fa fa-check"></i> Full support in Doubt solving</p>
                    <p class="animated bounceInLeft" style="animation-delay: 6s"><i class="fa fa-check"></i> Gurantee Job placements</p>
                    <p class="animated bounceInLeft" style="animation-delay: 7s"><i class="fa fa-check"></i> Attractive Price of Courses</p>
                  </div>
                </div>
              </div>

              <div class="acolumn">
                <div class="acard">
                  <img src="imgs/ofline.png" alt="Mike" style="width:100%">
                  <div class="acontainer">
                    <h2 class="animated slideInDown" style="animation-delay: 1s">Classroom Learnings</h2>
                    <p class="animated zoomIn" style="animation-delay: 2s">We provide group or one to one offline/class room training with</p>
                    <p class="animated zoomIn" style="animation-delay: 2s">conceptual and practical training In projector and laptop Student carry</p>
                    <p class="animated zoomIn" style="animation-delay: 2s">own laptop or can use class laptop</p>
                   
                  </div>
                </div>
              </div>
              
              <div class="acolumn">
                <div class="acard">
                  <img src="imgs/online.png" alt="John" style="width:100%">
                  <div class="acontainer">
                    <h2 class="animated bounceInRight" style="animation-delay: 1s">Online Learning</h2>
                    <p class="animated bounceInRight" style="animation-delay: 2s">We provide online training with good quality and knowledge under</p>
                    <p class="animated bounceInRight" style="animation-delay: 3s">experience faculty and low cost We provide recording after online</p>
                    <p class="animated bounceInRight" style="animation-delay: 4s">session completed Online platform refer :-</p>
                    <p class="animated bounceInRight" style="animation-delay: 5s"><i class="fa fa-circle"></i> Google meet</p>
                    <p class="animated bounceInRight" style="animation-delay: 6s"><i class="fa fa-circle"></i> Zoom</p>
                  </div>
                </div>
              </div>
            </div>

    </section>

<!-------------------------------------------About End------------------------------------------------------------>

<!------------------------------------------courses Start------- ------------------------------------------->

        <section id="courses">

            <h2 class="courp">High Demanding IT Courses In Industry</h2>
            <h4 style="text-align:center; color: #F1BC0A; font-weight:500;">Computer & Software Courses Training Institute in Borivali, Western Mumbai</h4>
            <h4 style="text-align:center; font-weight:350; font-size: 18px;">Learn best software courses from beginning to advance level at very affordable fees with placement assistance</h4>
            <hr>

            <div class="row1">
              <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/java.png" alt="Jane" style="width:100%">
                  <div class="containerp">
                    <h3>JAVA</h3>
                    <p>Learn java Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>

             <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/python.png" alt="Mike" style="width:100%">
                  <div class="containerp">
                    <h3>PYTHON</h3>
                    <p>Learn Python Programming for best career opportunities in business analytics</p> 
                     <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>                 
                     <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>

               <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/cc.jpg" alt="Mike" style="width:100%">
                  <div class="containerp">
                    <h3>C & C++</h3>
                    <p>Learn C & C++ Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>
                     <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>
              
             <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/php.jpg" alt="John" style="width:100%">
                 <div class="containerp">
                    <h3>PHP</h3>
                    <p>Learn Php Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>
            </div>

         <h2 style="text-align:center; font-weight: bold;">Explore New Courses Industry In-Demand IT Courses</h2>
            <marquee>
            <h4 style="text-align:center; font-weight:500; color: red;">Based on heavy demand from Industry, we are launching new courses soon!!</h4>
          </marquee>
            <div class="row1">
              <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/nodejs.jpeg" alt="Jane" style="width:100%">
                  <div class="containerp">
                    <h3>NODE JS</h3>
                    <p>Learn Node js Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>

             <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/reactjs.png" alt="Mike" style="width:100%">
                  <div class="containerp">
                    <h3>REACT JS/NATIVE</h3>
                    <p>Learn React JS/Native Programming for best career opportunities in business analytics</p> 
                     <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>                 
                     <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>

               <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/ds.jpeg" alt="Mike" style="width:100%">
                  <div class="containerp">
                    <h3>DATA SCIENCE</h3>
                    <p>Learn Data Science Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>
                     <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th> 
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>
              
             <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/haddop.png" alt="John" style="width:100%">
                 <div class="containerp">
                    <h3>HADOOP</h3>
                    <p>Learn Hadpop Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses" onclick="popup1()">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1"><a href="#footer" style="color:white;">Enquire Now</a></button></p>
                  </div>
                </div>
              </div>
            </div>

            <div id="more">
              <h4><a href="courses.php" id="btnall" onclick="popup11()">View All Courses > ></a></h4>
            </div>


        </section>

<!--------------------------------------------courses end------- ------------------------------------------->

 <!--------------------------------------------gallery Start------- ------------------------------------------->

<section id="gallery">
  
                          <div class="gcontainer">
                        <div class="gheader">
                        <h2>Gallery</h2>
                        <div class="gline"></div>
                      </div>
                     </div>

                <div class="grow"> 
                  <div class="gcolumn">
                    <img src="imgs/android.jpg" style="width:100%">
                    <img src="imgs/cc.jpg" style="width:100%">
                    <img src="imgs/dotnet.png" style="width:100%">
                    <img src="imgs/haddop.png" style="width:100%">
                    <img src="imgs/gst.jpg" style="width:100%">
                    <img src="imgs/fa.jpg" style="width:100%">
                  </div>
                  <div class="gcolumn">
                    <img src="imgs/java.png" style="width:100%">
                    <img src="imgs/android.jpg" style="width:100%">
                    <img src="imgs/cc.jpg" style="width:100%">
                    <img src="imgs/haddop.png" style="width:100%">
                    <img src="imgs/dotnet.png" style="width:100%">
                    <img src="imgs/android.jpg" style="width:100%">
                  </div>  
                  <div class="gcolumn">
                    <img src="imgs/java.png" style="width:100%">
                    <img src="imgs/android.jpg" style="width:100%">
                    <img src="imgs/cc.jpg" style="width:100%">
                    <img src="imgs/haddop.png" style="width:100%">
                    <img src="imgs/dotnet.png" style="width:100%">
                    <img src="imgs/android.jpg" style="width:100%">
                  </div>
                  <div class="gcolumn">
                    <img src="imgs/java.png" style="width:100%">
                    <img src="imgs/android.jpg" style="width:100%">
                    <img src="imgs/cc.jpg" style="width:100%">
                    <img src="imgs/haddop.png" style="width:100%">
                    <img src="imgs/dotnet.png" style="width:100%">
                    <img src="imgs/android.jpg" style="width:100%">
                  </div>
                </div>

</section>

	<!--------------------------------------------gallery End------- ------------------------------------------->


  <!--------------------------------------------teacher Start------- ------------------------------------------->
    <section id="OurTeachers">
  
      <div class="container1">
        <h1 class="heading1"><span>meet</span>Our Teachers</h1>

        <div class="profiles">
          <div class="profile">
            <img src="tec/tg1.png" class="profile-img">
            <h3 class="user-name">Kirti Singh</h3>
            <h5>SOFTWARE</h5>
            <p>Teachers have three loves: love of learning, love of learners, and the love of bringing the first two loves together.</p>
          </div>
          <div class="profile">
            <img src="tec/tb1.png" class="profile-img">
            <h3 class="user-name">Arun Jain</h3>
            <h5>NON-IT</h5>
            <p>Teachers have three loves: love of learning, love of learners, and the love of bringing the first two loves together.</p>
          </div>
          <div class="profile">
            <img src="tec/tb2.png" class="profile-img">
            <h3 class="user-name">Om Prakash</h3>
            <h5>ACCOUNTING</h5>
            <p>Teachers have three loves: love of learning, love of learners, and the love of bringing the first two loves together.</p>
          </div>
        </div>
      </div>

    </section>
  <!--------------------------------------------teacher End--------------------------------------------------->

<!-------------------------------footer Start------------------------------------------------->
    <div id="footer">
      

          <div class="footer">
                <div class="fcolumn">
                    <div class="fcontainer">
                  <h2>Courses Enquiry</h2>
                      <form  action="request_connection.php" id="qform" method="POST">
                        <div class="qcontainer">
                      <input type="email" name="email" placeholder="Enter Your Email I'D" required> <br>

                      <select name="course">
                        <option>Select Course</option>
                         <option value="Java">Java</option>
                         <option value="Python">Python</option>
                         <option value="C & C++">C & C++</option>
                         <option value="php">Php</option>
                         <option value="Hadoop">Hadoop</option>
                         <option value="Node JS">Node js</option>
                         <option value="React js/Native">React JS/Native</option>
                         <option value="Data Science">Data Science</option>
                         <option value="Other">Other</option>
                      </select> 
                      <br>

                       <input type="text" name="query" placeholder="Enter Your Query" required>
                       <br>

                       <input type="hidden" name="name_eq" value="<?php echo $_SESSION['name'] ?>">

                       <input type="hidden" name="mobile_eq" value="<?php echo $_SESSION['mobile'] ?>">

                      <input class="btn" type="submit" name="submit_eq">
                      </div>
                      </form>
                    </div>
                  </div>

                <div class="fcolumn">
                    <div class="fcontainer">
                      <h2>KRIT EDUCATION</h2>
                      <p><a href="#home">Home</a></p>
                      <p><a href="#about">About</a></p>
                      <p><a href="#courses">Courses</a></p>
                      <p><a href="#gallery">Gallery</a></p>
                      <p><a href="#OurTeachers">Our Teachers</a></p>
                    </div>
                  </div>

                <div class="fcolumn">
                    <div class="fcontainer">
                      <h2>CONTACT</h2>
                      <p>Address: G-01, First Floor, Near-Borivali Station</p>
                      <p>Borivali, Mumbai, Maharashtra, 123456, India</p>
                      <p>Contact No: +91 9876543210</p>
                    </div>
                  </div>
                  <div class="footer1">
                  <a href="#home">FAQ</a> ||
                  <a href="#home">Privacy Policy</a> ||
                  <a href="#home">Terms and Conditions</a> ||
                  <a href="#home">Refund Policy</a>
                  <p>Copyright &copy; 2021. All rights reserved with krit solution</p>
          </div>
                </div>

    </div>

 <!-----------------------footer End--------------------------------------------------->



<!-- --------------------Quick query java script popup-------------------------------------->

    <script>
// demo popup

        function popuph(){
            $('#popupmaineq_demo').css('display','block');
            $('.closedeq').click(function(){
            $('#popupmaineq_demo').css('display','none');
            });

        var email = document.getElementById("poptexteq3_demo").value;
        var selectop = document.getElementById("poptexteq4_demo").value;
        var qy = document.getElementById("poptexteq5_demo").value;
        
        if(email == ""){
                var e= document.getElementById("poptexteqe").value;
                document.getElementById("popmsg").innerHTML= e;
                return false;
                 }
        if (email.indexOf('@')<=0) {
                 var e1= document.getElementById("poptexteqe1").value;
                document.getElementById("popmsg").innerHTML= e1;
                return false;
                 }
        if ((email.charAt(email.length-4)!='.')  && (a.charAt(a.length-3)!='.')) {
               var e2= document.getElementById("poptexteqe2").value;
                document.getElementById("popmsg").innerHTML= e2;
                return false;
                 } 

        if(selectop.selectedIndex == 0){
                var s= document.getElementById("poptexteqs").value;
                document.getElementById("popmsg").innerHTML= s;
                return false;
              }
        if (qy == "") {
                 var q= document.getElementById("poptexteqq").value;
                document.getElementById("popmsg").innerHTML= q;
                return false;
                }

        }


// open Enqurynow query box

    function popupeq(){
            $('#popupmaineq').css('display','block');
            $('.closedeq').click(function(){
            $('#popupmaineq').css('display','none');
            });

        var name = document.getElementById("poptexteq1").value;
        var email = document.getElementById("poptexteq3").value;
        var selectop = document.getElementById("poptexteq4").value;
        var qy = document.getElementById("poptexteq5").value;

         if (name == "") {
                 var n= document.getElementById("poptexteqn").value;
                document.getElementById("popmsg").innerHTML= n;
                return false;
                }
        if ((name.length<=2) || (name.length>20)) {
                 var n1= document.getElementById("poptexteqn1").value;
                document.getElementById("popmsg").innerHTML= n1;
                return false;
                }
        
        if(email == ""){
                var e= document.getElementById("poptexteqe").value;
                document.getElementById("popmsg").innerHTML= e;
                return false;
                 }
        if (email.indexOf('@')<=0) {
                 var e1= document.getElementById("poptexteqe1").value;
                document.getElementById("popmsg").innerHTML= e1;
                return false;
                 }
        if ((email.charAt(email.length-4)!='.')  && (a.charAt(a.length-3)!='.')) {
               var e2= document.getElementById("poptexteqe2").value;
                document.getElementById("popmsg").innerHTML= e2;
                return false;
                 } 

        if(selectop.selectedIndex == 0){
                var s= document.getElementById("poptexteqs").value;
                document.getElementById("popmsg").innerHTML= s;
                return false;
              }
        if (qy == "") {
                 var q= document.getElementById("poptexteqq").value;
                document.getElementById("popmsg").innerHTML= q;
                return false;
                }

            }  
         

    </script>

<!-- -----------------Quick query java script popup--end------------------------------------>

</body>
</html>