<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login And Registration Form</title>
	<link rel="stylesheet" type="text/css" href="css/stylelogin.css">

<!-- 	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

	<style>
		.hero{
			background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url('imgs/loginbg.jpg');
		}
	</style>
</head>
<body>

	<div class="hero">
		<div class="form-box">
			<div class="button-box">
				<div id="btn"></div>
				<button type="button" class="toggle-btn" onclick="login()">Log In</button>
				<button type="button" class="toggle-btn" onclick="register()">Register</button>
		    </div>

		    <form id="login" class="input-group" action="logincheck.php" method="POST">
		    
		    <input type="text"class="input-field" placeholder="&#xf007; Enter Name"  id="lname" name="name"  required>
		     <span id="Lname" class="text-danger font-weight-bold"></span>
		    
		    <input type="number" class="input-field" placeholder="&#xf3cd; Enter Mobile No." id="lmobile" name="mobile" required>
		     <span id="Lmobile" class="text-danger font-weight-bold"></span>
		    <div>
		    <input type="checkbox" class="check-box"><span class="rp">Remember Password</span>
		    </div>
		    <button type="submit" class="submit-btn" onclick="disableText()" id="myBtnL" name="submit">Log in</button>

		    </form>


		    <form id="register" class="input-group" action="logincheck.php" method="POST">
		    	<input type="hidden" id="sosms" value="OTP is send to Your Mobile Number !!">

		        <input type="text" class="input-field" placeholder="&#xf007; Enter Name" id="name" name="rname" required>
		        <span id="Name" class="text-danger font-weight-bold"></span>

		        <input type="number" class="input-field" placeholder="&#xf3cd; Enter Mobile No."  id="mobile" name="rmobile" required>
		        <span id="Mobileno" class="text-danger font-weight-bold"></span>

		        <input type="number" class="input-field" placeholder="&#xf7cd; Enter OTP." id="otp" name="otp" hidden required>
		         <br>
		         <br>
			<button type="submit" id="myBTN" class="submit-btn" onclick="disableTxt()" name="rsubmit">Verified Mobile Number</button>
			    <br>

		    	<p id="msg"></p>
		   

		    </form>            
			</div>
		   </div>
    
    <script>
    var x= document.getElementById("login");
    var y= document.getElementById("register");
    var z= document.getElementById("btn");  
        
    function register(){
        x.style.left="-400px";
        y.style.left="50px";
        z.style.left="110px";
    }    
    
    function login(){
        x.style.left="50px";
        y.style.left="450px";
        z.style.left="0";
    } 

	function disableTxt() {
		var mobile = document.getElementById("mobile").value;
		var name = document.getElementById("name").value;

		if (name == "") {
				    document .getElementById("Name").innerHTML="** Please Fill UserName";
				return false;
				}

		if (mobile == "") {
				document .getElementById("Mobileno").innerHTML="** Please Fill Mobile Number ";
				return false;
				}

		if (isNaN(mobile)) {
				document .getElementById("Mobileno").innerHTML="** Enter only Numeric value ";
				return false;
				}

		if (mobile.length!=10) {
				document .getElementById("Mobileno").innerHTML="** Mobile Number must be 10 digit";
				return false;
				}

		if ((mobile.charAt(0)!=9) && (mobile.charAt(0)!=8) && (mobile.charAt(0)!=7) && (mobile.charAt(0)!=6)) {
				document .getElementById("Mobileno").innerHTML="** Mobile Number must start with 9,8,7,6. ";
				return false;	
				}

				document.getElementById("otp").hidden = false;

				var x = document.getElementById("sosms").value;
				document.getElementById("msg").innerHTML = x;
				
				var y = document.getElementById("myBTN");
				  if (y.innerHTML === "Verified Mobile Number") {
				    y.innerHTML = "Verified OTP";
				  }
			}  


function disableText() {
	var n = document.getElementById("lname").value;
	var m = document.getElementById("lmobile").value;

	if (n == "") {
		document .getElementById("Lname").innerHTML="** Please Fill UserName";
		return false;
		}

	if (m =="") {
		document .getElementById("Lmobile").innerHTML="**  Please Fill Mobile Number";
		return false;
		}	

}
    
    </script>

</body>
</html>
