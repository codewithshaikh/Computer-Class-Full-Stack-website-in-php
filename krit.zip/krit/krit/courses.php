<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>All Courses</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="css/course.css">

	<style>
		
	</style>
</head>
<body>

	<nav>

		<input type="checkbox"id="check">
		<label for="check" class="checkbtn">
			<i class="fas fa-bars"></i>
		</label>
		
		<label class="logo">KRIT EDUCATION</label>

		<ul>
			<li><a class="active" href="home.php"><i class="fa-solid fa-house-user"></i> Home</a></li>
			<li><a href="home.php"><i class="fas fa-coffee"></i> About</a></li>
			<li><a href="home.php"><i class="fab fa-css3-alt"></i> Courses</a></li>
			<li><a href="home.php"><i class="fab fa-envira"></i> Gallery</a></li>
			<li><a href="home.php"><i class="fas fa-chalkboard-teacher"></i> Our Teachers</a></li>
			<li><a href="home.php"><i class="fas fa-phone"></i> Contact</a></li>
		</ul>
	</nav>


	<section id="about" style="padding-top: 100px;">

            <div class="arow">
             <!-- <div class="columnp w3-hover-shadow"> -->
              <div class="acolumn">
                <div class="acard">
                  <img src="imgs/java.png" alt="Jane" style="width:60vh; height: 250px;">
                  <div class="containerp">
                  	<h3>JAVA</h3>
                    <p>Learn java Programming for best career opportunities in business analytics</p>
                    <p style="text-align:center">View <a href="#courses">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p> 
                  </div>
                </div>
              </div>


              <div class="acolumn">
                <div class="acard">
                  <img src="imgs/python.png" alt="Mike" style="width:60vh;height: 250px;">
                  <div class="containerp">
                  	<h3>JAVA</h3>
                    <p>Learn java Programming for best career opportunities in business analytics</p>
                    <p style="text-align:center;">View <a href="#courses">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p>
                  </div>
                </div>
              </div>
              
              <div class="acolumn">
                <div class="acard">
                  <img src="imgs/cc.jpg" alt="John" style="width:60vh; height:250px">
                  <div class="containerp">
                  	<h3>JAVA</h3>
                    <p>Learn java Programming for best career opportunities in business analytics</p>
                   <p style="text-align:center">View <a href="#courses">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p>
                  </div>
                </div>
              </div>
     </div>

    </section>

<br>
<br>

	 <section id="courses">

            <h2 class="courp">High Demanding IT Courses In Industry</h2>
            <h4 style="text-align:center; color: #F1BC0A; font-weight:500;">Computer & Software Courses Training Institute in Borivali, Western Mumbai</h4>
            <h4 style="text-align:center; font-weight:350; font-size: 18px;padding-bottom: 20px;">Learn best software courses from beginning to advance level at very affordable fees with placement assistance</h4>
            <hr>
            <br>

            <div class="row1">
              <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/java.png" alt="Jane" style="width:100%">
                  <div class="containerp">
                    <h3>JAVA</h3>
                    <p>Learn java Programming for best career opportunities in business analytics</p>
                    <p>View <a href="#courses">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p>
                  </div>
                </div>
            </div>

             <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/python.png" alt="Mike" style="width:100%">
                  <div class="containerp">
                    <h3>PYTHON</h3>
                    <p>Learn Python Programming for best career opportunities in business analytics</p> 
                     <p >View <a href="#courses">Brochure</a></p>                 
                     <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p>
                  </div>
                </div>
              </div>

               <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/cc.jpg" alt="Mike" style="width:100%">
                  <div class="containerp">
                    <h3>C & C++</h3>
                    <p>Learn C & C++ Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses">Brochure</a></p>
                     <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p>
                  </div>
                </div>
              </div>
              
             <div class="columnp w3-hover-shadow">
                <div class="cardp">
                  <img src="imgs/php.jpg" alt="John" style="width:100%">
                 <div class="containerp">
                    <h3>PHP</h3>
                    <p>Learn Php Programming for best career opportunities in business analytics</p>
                    <p >View <a href="#courses">Brochure</a></p>
                    <table class="table">
                   <thead>
                    <th style="text-align: center;">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </th>
                    <tr>
                      <th scope="col" >Classroom Learning</th>
                      <th scope="col">Online Learning</th>
                    </tr>
                  </thead>
                  </table>
                    <p><button class="button1">Enquire Now</button></p>
                  </div>
                </div>
              </div>
            </div>
</section>


</body>
</html>