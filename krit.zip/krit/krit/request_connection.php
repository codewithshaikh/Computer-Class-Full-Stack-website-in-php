<?php

    $con= mysqli_connect('localhost','root','','krit');

      // if ($con==TRUE) {
      //         echo "Conneted to database successfully";      // database name-: krit
      // }else{                                             // table name -:  request_connection
      //   echo "Not Conneted to database";
      // }
          if (isset($_POST['submit_eq'])) {
                $name=$_POST['name_eq'];
                $mobile=$_POST['mobile_eq'];
                $email=$_POST['email'];
                $course=$_POST['course'];
                $query=$_POST['query'];


          $qy = "INSERT INTO `request_connection`(`name`,`mobile`,`email`, `course`, `query`) value ('$name' ,'$mobile','$email' , '$course' , '$query')";

              

              $run = mysqli_query($con,$qy);

               if($run==TRUE){

                echo "<script>
                       alert('Thanks for Providing Your Query, Our Team Will Contact In Working 24 hours');
                        window.location.href='home.php';
                     </script>";
            }else{

                // echo " Error ".$con->error;  // ( error findout)

                echo "<script>
                       alert(' Request is not submited');
                        window.location.href='home.php';
                     </script>";
                }

          }


//////////////////////////////////////////////////////// demo Connection


           if (isset($_POST['submit_d'])) {
                $name_d=$_POST['name_d'];
                $email_d=$_POST['email_d'];
                $date_d=$_POST['date_d'];
                $course_d=$_POST['selectop_d'];
                $query_d=$_POST['query_d'];


          $qry = "INSERT INTO `demo`(`name`, `email`, `sdate`, `course`, `query`) value ('$name_d' ,'$email_d' , '$date_d' , '$course_d' , '$query_d')";



              

              $rn = mysqli_query($con,$qry);

               if($rn==TRUE){

                echo "<script>
                       alert(' Request is Successfully submited');
                        window.location.href='home.php';
                     </script>";
            }else{

                // echo " Error ".$con->error;  // ( error findout)

                echo "<script>
                       alert(' Request is not submited');
                        window.location.href='home.php';
                     </script>";
                }

          }

  ?>